'use client'

import { useCareData, useSession } from '@/lib/care-store'
import type { CareData, Patient, Session } from '@/lib/types'
import { EmptyState, ErrorState, LoadingState } from './states'

interface ProtectedShellProps {
  role: Session['role']
  children: (args: { session: Session; data: CareData }) => React.ReactNode
}

export function ProtectedShell({ role, children }: ProtectedShellProps) {
  const session = useSession()
  const { data, error, isLoading, mutate } = useCareData()

  if (!session || session.role !== role) return null
  if (error) return <ErrorState onRetry={() => mutate()} />
  if (isLoading || !data) return <LoadingState />
  return <>{children({ session, data })}</>
}

export function PatientShell({ children }: { children: (args: { patient: Patient; data: CareData }) => React.ReactNode }) {
  return (
    <ProtectedShell role="patient">
      {({ session, data }) => {
        const patient = session.role === 'patient' ? data.patients.find((p) => p.id === session.patientId) : undefined
        if (!patient) return <EmptyState message="We could not find your care record." />
        return children({ patient, data })
      }}
    </ProtectedShell>
  )
}
