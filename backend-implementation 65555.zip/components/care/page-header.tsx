export function PageHeader({ title, description, action }: { title: string; description?: string; action?: React.ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="text-2xl font-semibold leading-tight text-balance md:text-3xl">{title}</h1>
        {description && <p className="mt-1.5 text-base text-muted-foreground text-pretty">{description}</p>}
      </div>
      {action}
    </div>
  )
}
