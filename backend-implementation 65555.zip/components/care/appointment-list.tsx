import { AlertTriangle, CalendarCheck, CalendarClock, CalendarDays, CalendarX, CheckCircle2, Clock, RefreshCw } from 'lucide-react'
import { formatDate, formatTime } from '@/lib/format'
import { cn } from '@/lib/utils'
import type { Appointment, AppointmentStatus, AttendanceStatus } from '@/lib/types'
import { Section } from './section'
import { EmptyState } from './states'
import { Badge } from './status-badge'

const statusBadge: Record<AppointmentStatus, Parameters<typeof Badge>[0]['config']> = {
  scheduled: { label: 'Scheduled', icon: CalendarClock, tone: 'info' },
  completed: { label: 'Completed', icon: CheckCircle2, tone: 'success' },
  missed: { label: 'Missed', icon: CalendarX, tone: 'danger' },
  rescheduled: { label: 'Rescheduled', icon: RefreshCw, tone: 'neutral' },
}

const attendanceBadge: Record<AttendanceStatus, Parameters<typeof Badge>[0]['config']> = {
  upcoming: { label: 'Upcoming', icon: Clock, tone: 'neutral' },
  attended: { label: 'Attended', icon: CheckCircle2, tone: 'success' },
  not_attended: { label: 'Not Attended', icon: CalendarX, tone: 'danger' },
}

export function sortAppointments(appointments: Appointment[]) {
  return [...appointments].sort((a, b) => new Date(b.at).getTime() - new Date(a.at).getTime())
}

export function AppointmentItem({ appointment, viewer = 'patient', patientName }: { appointment: Appointment; viewer?: 'patient' | 'coordinator'; patientName?: string }) {
  const needsAttention = appointment.status === 'missed'
  return (
    <li className={cn('rounded-lg border bg-background p-4', needsAttention && 'border-danger/40 bg-danger-soft/40')}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          {patientName && <p className="text-sm font-medium text-primary">{patientName}</p>}
          <h3 className="text-lg font-semibold">{appointment.title}</h3>
          <p className="text-base text-muted-foreground">
            {appointment.doctor}
            {appointment.department && ` · ${appointment.department}`}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Badge config={statusBadge[appointment.status]} />
        </div>
      </div>
      <dl className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <div>
          <dt className="text-sm text-muted-foreground">Date</dt>
          <dd className="text-base font-medium">{formatDate(appointment.at)}</dd>
        </div>
        <div>
          <dt className="text-sm text-muted-foreground">Time</dt>
          <dd className="text-base font-medium">{formatTime(appointment.at)}</dd>
        </div>
        <div>
          <dt className="text-sm text-muted-foreground">Attendance</dt>
          <dd className="mt-0.5">
            <Badge config={attendanceBadge[appointment.attendance]} />
          </dd>
        </div>
        <div>
          <dt className="text-sm text-muted-foreground">Follow-up</dt>
          <dd className="text-base font-medium">{appointment.followUp ?? 'None'}</dd>
        </div>
      </dl>
      {needsAttention && (
        <p className="mt-3 flex items-start gap-2 rounded-md border border-danger/30 bg-card px-3 py-2 text-base font-medium text-danger">
          <AlertTriangle className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
          {viewer === 'patient'
            ? 'You missed this appointment. Your care coordinator will contact you to reschedule.'
            : 'Patient did not attend the scheduled appointment.'}
        </p>
      )}
    </li>
  )
}

export function AppointmentList({ appointments }: { appointments: Appointment[] }) {
  const sorted = sortAppointments(appointments)
  const upcoming = sorted.filter((a) => a.status === 'scheduled').reverse()
  const attention = sorted.filter((a) => a.status === 'missed')
  const past = sorted.filter((a) => a.status === 'completed' || a.status === 'rescheduled')

  const groups = [
    { id: 'attention', title: 'Requires Attention', icon: AlertTriangle, items: attention },
    { id: 'upcoming', title: 'Upcoming', icon: CalendarDays, items: upcoming },
    { id: 'past', title: 'Past Appointments', icon: CalendarCheck, items: past },
  ].filter((g) => g.items.length > 0)

  if (groups.length === 0) return <EmptyState message="No appointments scheduled." />

  return (
    <div className="flex flex-col gap-6">
      {groups.map((g) => (
        <Section key={g.id} id={`appointments-${g.id}`} title={g.title} icon={g.icon}>
          <ul className="flex flex-col gap-3">
            {g.items.map((a) => (
              <AppointmentItem key={a.id} appointment={a} />
            ))}
          </ul>
        </Section>
      ))}
    </div>
  )
}
