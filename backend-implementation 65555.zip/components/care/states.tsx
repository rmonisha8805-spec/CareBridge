import { AlertCircle, Inbox, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function LoadingState({ label = 'Loading care information...' }: { label?: string }) {
  return (
    <div role="status" className="flex flex-col items-center justify-center gap-3 py-24 text-muted-foreground">
      <Loader2 className="size-8 animate-spin text-primary" aria-hidden="true" />
      <p className="text-base">{label}</p>
    </div>
  )
}

export function EmptyState({ message }: { message: string }) {
  return (
    <div className="flex items-center gap-3 rounded-lg border border-dashed bg-muted/40 px-4 py-6 text-muted-foreground">
      <Inbox className="size-5 shrink-0" aria-hidden="true" />
      <p className="text-base">{message}</p>
    </div>
  )
}

export function ErrorState({ onRetry }: { onRetry: () => void }) {
  return (
    <div role="alert" className="mx-auto flex max-w-md flex-col items-center gap-4 py-24 text-center">
      <AlertCircle className="size-10 text-danger" aria-hidden="true" />
      <div>
        <p className="text-lg font-semibold">Unable to load care information.</p>
        <p className="text-muted-foreground">Please check your connection and try again.</p>
      </div>
      <Button onClick={onRetry} className="h-11 px-5 text-base">
        Try Again
      </Button>
    </div>
  )
}
