'use client'

import { useState } from 'react'
import { Settings } from 'lucide-react'
import { Section } from './section'

interface Preference {
  id: string
  label: string
  description: string
  defaultOn: boolean
}

export function SettingsPanel({ preferences }: { preferences: Preference[] }) {
  const [values, setValues] = useState<Record<string, boolean>>(() => Object.fromEntries(preferences.map((p) => [p.id, p.defaultOn])))

  return (
    <Section id="settings" title="Notification Preferences" icon={Settings}>
      <ul className="flex flex-col divide-y">
        {preferences.map((p) => {
          const on = values[p.id]
          return (
            <li key={p.id} className="flex items-center justify-between gap-4 py-4 first:pt-0 last:pb-0">
              <div>
                <p id={`${p.id}-label`} className="text-base font-medium">
                  {p.label}
                </p>
                <p className="text-sm text-muted-foreground">{p.description}</p>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={on}
                aria-labelledby={`${p.id}-label`}
                onClick={() => setValues((v) => ({ ...v, [p.id]: !v[p.id] }))}
                className={`relative h-7 w-12 shrink-0 rounded-full transition-colors ${on ? 'bg-primary' : 'bg-muted'}`}
              >
                <span
                  aria-hidden="true"
                  className={`absolute top-1 size-5 rounded-full bg-card shadow transition-transform ${on ? 'translate-x-6' : 'translate-x-1'}`}
                />
              </button>
            </li>
          )
        })}
      </ul>
    </Section>
  )
}
