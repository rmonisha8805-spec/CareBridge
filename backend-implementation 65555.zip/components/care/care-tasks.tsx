import { CalendarCheck, ClipboardList, House, Pill, type LucideIcon } from 'lucide-react'
import type { CareTask, TaskType } from '@/lib/types'
import { Section } from './section'
import { EmptyState } from './states'
import { StatusBadge } from './status-badge'

export const taskTypeMeta: Record<TaskType, { label: string; icon: LucideIcon }> = {
  appointment: { label: 'Appointment', icon: CalendarCheck },
  medicine: { label: 'Medicine', icon: Pill },
  home_care: { label: 'Home Care', icon: House },
}

export function CareTasks({ tasks }: { tasks: CareTask[] }) {
  return (
    <Section id="care-tasks" title="Care Tasks" description="Every part of your recovery plan and where it stands." icon={ClipboardList}>
      {tasks.length === 0 ? (
        <EmptyState message="No active care tasks." />
      ) : (
        <ul className="grid gap-3 md:grid-cols-3">
          {tasks.map((task) => {
            const meta = taskTypeMeta[task.type]
            const Icon = meta.icon
            return (
              <li key={task.id} className="flex flex-col gap-3 rounded-lg border bg-background p-4">
                <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                  <Icon className="size-4" aria-hidden="true" />
                  {meta.label}
                </div>
                <div>
                  <h3 className="text-base font-semibold">{task.title}</h3>
                  {task.detail && <p className="mt-0.5 text-sm text-muted-foreground">{task.detail}</p>}
                </div>
                <StatusBadge status={task.status} className="self-start" />
              </li>
            )
          })}
        </ul>
      )}
    </Section>
  )
}
