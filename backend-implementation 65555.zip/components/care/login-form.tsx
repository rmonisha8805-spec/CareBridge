'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Eye, EyeOff, Loader2, UserRound, UserRoundCog } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { signIn } from '@/lib/care-store'
import { cn } from '@/lib/utils'

const accounts = {
  patient: { email: 'priya.nair@example.com', password: 'patient123', name: 'Priya Nair', patientId: 'p1' },
  coordinator: { email: 'kavya.menon@carebridge.health', password: 'coord123', name: 'Kavya Menon', coordinatorId: 'c1' },
}

type Role = keyof typeof accounts

export function LoginForm() {
  const router = useRouter()
  const [role, setRole] = useState<Role>('patient')
  const [email, setEmail] = useState(accounts.patient.email)
  const [password, setPassword] = useState(accounts.patient.password)
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)

  function chooseRole(next: Role) {
    setRole(next)
    setEmail(accounts[next].email)
    setPassword(accounts[next].password)
    setError(null)
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    const account = accounts[role]
    if (email.trim().toLowerCase() !== account.email || password !== account.password) {
      setError('Email or password is incorrect. Use the demo credentials shown below.')
      return
    }
    setSubmitting(true)
    if (role === 'patient') {
      await signIn({ role: 'patient', name: accounts.patient.name, patientId: accounts.patient.patientId })
      router.push('/patient')
    } else {
      await signIn({ role: 'coordinator', name: accounts.coordinator.name, coordinatorId: accounts.coordinator.coordinatorId })
      router.push('/coordinator')
    }
  }

  const roles: { value: Role; label: string; icon: typeof UserRound }[] = [
    { value: 'patient', label: 'Patient', icon: UserRound },
    { value: 'coordinator', label: 'Care Coordinator', icon: UserRoundCog },
  ]

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-5" noValidate>
      <fieldset>
        <legend className="mb-2 text-sm font-medium">I am signing in as</legend>
        <div className="grid grid-cols-2 gap-2 rounded-xl bg-muted p-1">
          {roles.map(({ value, label, icon: Icon }) => (
            <label
              key={value}
              className={cn(
                'flex h-11 cursor-pointer items-center justify-center gap-2 rounded-lg text-sm font-medium transition-colors has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-ring',
                role === value ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground',
              )}
            >
              <input type="radio" name="role" value={value} checked={role === value} onChange={() => chooseRole(value)} className="sr-only" />
              <Icon className="size-4" aria-hidden="true" />
              {label}
            </label>
          ))}
        </div>
      </fieldset>

      <label className="flex flex-col gap-1.5 text-sm font-medium">
        Email address
        <input
          type="email"
          autoComplete="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="h-11 rounded-lg border border-input bg-background px-3 text-base outline-none focus-visible:ring-2 focus-visible:ring-ring/40"
        />
      </label>

      <label className="flex flex-col gap-1.5 text-sm font-medium">
        Password
        <span className="relative">
          <input
            type={showPassword ? 'text' : 'password'}
            autoComplete="current-password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="h-11 w-full rounded-lg border border-input bg-background px-3 pr-11 text-base outline-none focus-visible:ring-2 focus-visible:ring-ring/40"
          />
          <button
            type="button"
            onClick={() => setShowPassword((s) => !s)}
            aria-label={showPassword ? 'Hide password' : 'Show password'}
            className="absolute inset-y-0 right-0 flex w-11 items-center justify-center text-muted-foreground hover:text-foreground"
          >
            {showPassword ? <EyeOff className="size-4" aria-hidden="true" /> : <Eye className="size-4" aria-hidden="true" />}
          </button>
        </span>
      </label>

      {error && (
        <p role="alert" className="rounded-lg border border-danger/30 bg-danger-soft p-3 text-sm font-medium text-danger">
          {error}
        </p>
      )}

      <Button type="submit" disabled={submitting} className="h-12 text-base">
        {submitting && <Loader2 className="animate-spin" aria-hidden="true" />}
        {role === 'patient' ? 'Sign in to my care' : 'Sign in to dashboard'}
      </Button>

      <div className="rounded-lg border border-dashed bg-muted/50 p-3 text-sm text-muted-foreground">
        <p className="font-medium text-foreground">Demo credentials</p>
        <p className="mt-1 break-all">
          {accounts[role].email} · {accounts[role].password}
        </p>
      </div>
    </form>
  )
}
