import { AlertTriangle, Bell, Check, Circle, History, UserRoundCog, X, type LucideIcon } from 'lucide-react'
import { formatDate, formatTime } from '@/lib/format'
import { cn } from '@/lib/utils'
import type { TimelineEvent, TimelineKind } from '@/lib/types'
import { taskTypeMeta } from './care-tasks'
import { Section } from './section'
import { EmptyState } from './states'

const kindMeta: Record<TimelineKind, { icon: LucideIcon; className: string; label: string }> = {
  info: { icon: Circle, className: 'bg-info-soft text-info border-info/30', label: 'Update' },
  success: { icon: Check, className: 'bg-success-soft text-success border-success/30', label: 'Completed step' },
  failed: { icon: X, className: 'bg-danger-soft text-danger border-danger/30', label: 'Failed' },
  escalated: { icon: AlertTriangle, className: 'bg-escalated-soft text-escalated border-escalated/30', label: 'Escalated' },
  coordinator: { icon: UserRoundCog, className: 'bg-secondary text-primary border-primary/30', label: 'Coordinator' },
  notification: { icon: Bell, className: 'bg-warning-soft text-warning border-warning/30', label: 'Notification' },
}

export function CareTimeline({ events, description }: { events: TimelineEvent[]; description?: string }) {
  const sorted = [...events].sort((a, b) => new Date(a.at).getTime() - new Date(b.at).getTime())

  return (
    <Section
      id="care-timeline"
      title="Care Timeline"
      description={description ?? 'A complete history of everything that has happened in your care.'}
      icon={History}
    >
      {sorted.length === 0 ? (
        <EmptyState message="No timeline events available." />
      ) : (
        <ol className="relative">
          {sorted.map((event, i) => {
            const meta = kindMeta[event.kind]
            const Icon = meta.icon
            return (
              <li key={event.id} className="relative flex gap-4 pb-6 last:pb-0">
                {i < sorted.length - 1 && <span aria-hidden="true" className="absolute left-[17px] top-9 bottom-0 w-0.5 bg-border" />}
                <span className={cn('relative z-10 flex size-9 shrink-0 items-center justify-center rounded-full border', meta.className)}>
                  <Icon className="size-4" aria-hidden="true" />
                  <span className="sr-only">{meta.label}</span>
                </span>
                <div className="flex-1 pt-1">
                  <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
                    <h3 className={cn('text-base font-semibold', event.kind === 'failed' && 'text-danger', event.kind === 'escalated' && 'text-escalated')}>
                      {event.title}
                    </h3>
                    <time dateTime={event.at} className="text-sm text-muted-foreground">
                      {formatDate(event.at)} · {formatTime(event.at)}
                    </time>
                  </div>
                  {event.description && <p className="mt-0.5 text-sm leading-relaxed text-muted-foreground">{event.description}</p>}
                  {event.taskType && (
                    <span className="mt-2 inline-block rounded-md bg-muted px-2 py-0.5 text-xs font-medium text-muted-foreground">
                      {taskTypeMeta[event.taskType].label}
                    </span>
                  )}
                </div>
              </li>
            )
          })}
        </ol>
      )}
    </Section>
  )
}
