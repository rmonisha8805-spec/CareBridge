'use client'

import { useState } from 'react'
import { ArrowDown, ArrowRight, BellRing, CalendarClock, CheckCircle2, Phone, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { contactPatient, rescheduleAppointment, resolveEscalation, sendMedicineReminder } from '@/lib/care-store'
import { formatDate, formatDateTime, formatTime } from '@/lib/format'
import { cn } from '@/lib/utils'
import type { Escalation, Patient } from '@/lib/types'
import { EscalationFacts } from './escalation-card'

function EscalationSequence({ patient, escalation }: { patient: Patient; escalation: Escalation }) {
  const taskType = escalation.category === 'medication' ? 'medicine' : 'appointment'
  const events = patient.timeline
    .filter((e) => e.taskType === taskType)
    .sort((a, b) => new Date(a.at).getTime() - new Date(b.at).getTime())

  return (
    <ol className="flex flex-col" aria-label="Escalation sequence">
      {events.map((e, i) => (
        <li key={e.id}>
          <div
            className={cn(
              'rounded-lg border px-3 py-2',
              e.kind === 'failed' && 'border-danger/30 bg-danger-soft',
              e.kind === 'escalated' && 'border-escalated/30 bg-escalated-soft',
              e.kind === 'coordinator' && 'border-primary/30 bg-secondary',
              e.kind === 'success' && 'border-success/30 bg-success-soft',
              (e.kind === 'info' || e.kind === 'notification') && 'bg-background',
            )}
          >
            <p className="text-base font-semibold">{e.title}</p>
            <p className="text-sm text-muted-foreground">
              {formatDate(e.at)} · {formatTime(e.at)}
            </p>
          </div>
          {i < events.length - 1 && <ArrowDown className="mx-auto my-0.5 size-4 text-muted-foreground" aria-hidden="true" />}
        </li>
      ))}
    </ol>
  )
}

export function ResolutionPanel({ patient, escalation, onClose }: { patient: Patient; escalation: Escalation; onClose: () => void }) {
  const [pending, setPending] = useState(false)
  const [when, setWhen] = useState('')
  const [note, setNote] = useState('')
  const [feedback, setFeedback] = useState<string | null>(null)
  const isAppointment = escalation.category === 'follow_up_appointment'
  const medicine = patient.medicines.find((m) => m.id === escalation.medicineId)
  const phoneHref = patient.phone ? `tel:${patient.phone.replace(/\s/g, '')}` : undefined

  async function run(action: () => Promise<unknown>, message: string) {
    setPending(true)
    await action()
    setFeedback(message)
    setPending(false)
  }

  return (
    <section aria-labelledby={`resolution-${escalation.id}`} className="border-t bg-muted/40 p-5">
      <div className="mb-5 flex items-center justify-between gap-3">
        <h3 id={`resolution-${escalation.id}`} className="text-xl font-semibold">
          Resolution
        </h3>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close resolution panel"
          className="flex size-9 items-center justify-center rounded-lg text-muted-foreground hover:bg-card"
        >
          <X className="size-5" aria-hidden="true" />
        </button>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.3fr_1fr]">
        <div className="flex flex-col gap-5">
          <div className="rounded-lg border bg-card p-4">
            <h4 className="mb-2 text-sm font-semibold uppercase tracking-wide text-muted-foreground">Patient contact</h4>
            <p className="text-lg font-semibold">{patient.name}</p>
            {patient.phone ? (
              <a href={phoneHref} className="mt-1 inline-flex items-center gap-2 text-lg font-semibold text-primary underline-offset-4 hover:underline">
                <Phone className="size-4" aria-hidden="true" />
                {patient.phone}
              </a>
            ) : (
              <p className="text-base text-muted-foreground">Phone: Not available</p>
            )}
          </div>

          <div className="rounded-lg border bg-card p-4">
            <EscalationFacts patient={patient} escalation={escalation} />
            {!isAppointment && medicine?.restockedAt && (
              <p className="mt-4 text-sm text-muted-foreground">
                Restock information: restocked on <span className="font-medium text-foreground">{formatDateTime(medicine.restockedAt)}</span>
              </p>
            )}
          </div>

          {!isAppointment && (
            <div className="rounded-lg border bg-card p-4">
              <h4 className="mb-2 text-sm font-semibold uppercase tracking-wide text-muted-foreground">Notification history</h4>
              <ul className="flex flex-col gap-1.5">
                {escalation.notificationHistory.map((n, i) => (
                  <li key={i} className="flex items-center justify-between gap-3 text-base">
                    <span className="flex items-center gap-2">
                      <BellRing className="size-4 text-warning" aria-hidden="true" />
                      {n.label}
                    </span>
                    <span className="text-sm text-muted-foreground">{formatDateTime(n.at)}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div className="rounded-lg border bg-card p-4">
            <h4 className="mb-2 text-sm font-semibold uppercase tracking-wide text-muted-foreground">Previous actions</h4>
            <ul className="flex flex-col gap-1.5">
              {escalation.previousActions.map((a, i) => (
                <li key={i} className="flex items-start gap-2 text-base">
                  <ArrowRight className="mt-1 size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
                  {a}
                </li>
              ))}
            </ul>
          </div>

          <div className="rounded-lg border bg-card p-4">
            <h4 className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted-foreground">Actions</h4>
            <div className="flex flex-wrap gap-2">
              <Button asChild variant="outline" className="h-11 px-4 text-base">
                <a href={phoneHref} onClick={() => run(() => contactPatient(patient.id, escalation.id), 'Call logged: patient contacted.')}>
                  <Phone aria-hidden="true" />
                  Contact Patient
                </a>
              </Button>
              {!isAppointment && (
                <Button
                  variant="outline"
                  disabled={pending}
                  onClick={() => run(() => sendMedicineReminder(patient.id, escalation.id), 'Reminder sent to the patient.')}
                  className="h-11 px-4 text-base"
                >
                  <BellRing aria-hidden="true" />
                  Send Reminder
                </Button>
              )}
            </div>

            {isAppointment && (
              <div className="mt-4 flex flex-wrap items-end gap-2">
                <div className="flex flex-col gap-1.5">
                  <label htmlFor={`when-${escalation.id}`} className="text-sm font-medium">
                    New date and time
                  </label>
                  <input
                    id={`when-${escalation.id}`}
                    type="datetime-local"
                    value={when}
                    onChange={(e) => setWhen(e.target.value)}
                    className="h-11 rounded-lg border border-input bg-background px-3 text-base"
                  />
                </div>
                <Button
                  variant="outline"
                  disabled={!when || pending}
                  onClick={() =>
                    run(async () => {
                      await rescheduleAppointment(patient.id, escalation.id, when)
                      setWhen('')
                    }, 'Appointment rescheduled and patient notified.')
                  }
                  className="h-11 px-4 text-base"
                >
                  <CalendarClock aria-hidden="true" />
                  Reschedule
                </Button>
              </div>
            )}

            <div className="mt-4 flex flex-col gap-1.5">
              <label htmlFor={`note-${escalation.id}`} className="text-sm font-medium">
                Resolution note (optional)
              </label>
              <textarea
                id={`note-${escalation.id}`}
                value={note}
                onChange={(e) => setNote(e.target.value)}
                rows={2}
                className="rounded-lg border border-input bg-background px-3 py-2 text-base"
                placeholder={isAppointment ? 'e.g. Patient agreed to attend the new slot.' : 'e.g. Family member collected the medicine.'}
              />
            </div>
            <Button
              disabled={pending}
              onClick={() => run(() => resolveEscalation(patient.id, escalation.id, note.trim()), 'Escalation resolved.')}
              className="mt-3 h-11 bg-success px-5 text-base text-primary-foreground hover:bg-success/90"
            >
              <CheckCircle2 aria-hidden="true" />
              Resolve
            </Button>

            {feedback && (
              <p role="status" className="mt-3 text-sm font-medium text-success">
                {feedback}
              </p>
            )}
          </div>
        </div>

        <div className="rounded-lg border bg-card p-4">
          <h4 className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            {isAppointment ? 'Appointment timeline' : 'Medication timeline'}
          </h4>
          <EscalationSequence patient={patient} escalation={escalation} />
        </div>
      </div>
    </section>
  )
}
