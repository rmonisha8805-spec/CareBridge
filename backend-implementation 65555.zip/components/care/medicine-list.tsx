import { Pill } from 'lucide-react'
import { formatDateTime } from '@/lib/format'
import { cn } from '@/lib/utils'
import type { Medicine, SupplyStatus } from '@/lib/types'
import { Section } from './section'
import { EmptyState } from './states'
import { SupplyBadge } from './status-badge'

const progression = ['Out of Stock', 'Restocking', 'Available', 'Collected', 'Verified']

const progressIndex: Record<SupplyStatus, number> = {
  out_of_stock: 0,
  restocking: 1,
  restocked: 2,
  available: 2,
  collected: 3,
  verified: 4,
}

function SupplyProgress({ status }: { status: SupplyStatus }) {
  const current = progressIndex[status]
  return (
    <ol className="mt-4 grid grid-cols-5 gap-1.5" aria-label={`Supply progress: ${progression[current]}`}>
      {progression.map((label, i) => {
        const reached = i <= current
        return (
          <li key={label} className="flex flex-col gap-1.5">
            <span
              aria-hidden="true"
              className={cn('h-1.5 rounded-full', reached ? (status === 'out_of_stock' ? 'bg-danger' : 'bg-success') : 'bg-muted')}
            />
            <span className={cn('text-xs leading-tight', i === current ? 'font-semibold text-foreground' : 'text-muted-foreground')}>
              {i === 2 && status === 'restocked' ? 'Restocked' : label}
              {i === current && <span className="sr-only"> (current)</span>}
            </span>
          </li>
        )
      })}
    </ol>
  )
}

export function MedicineList({ medicines, columns = 1 }: { medicines: Medicine[]; columns?: 1 | 2 }) {
  return (
    <Section
      id="medicines"
      title="Prescribed Medicines"
      description={`${medicines.length} prescribed ${medicines.length === 1 ? 'medicine' : 'medicines'}`}
      icon={Pill}
    >
      {medicines.length === 0 ? (
        <EmptyState message="No medicines prescribed." />
      ) : (
        <ul className={cn('grid gap-3', columns === 2 && 'lg:grid-cols-2')}>
          {medicines.map((m) => (
            <li key={m.id} className="rounded-lg border bg-background p-4">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <h3 className="text-lg font-semibold">{m.name}</h3>
                  {m.dosage && <p className="text-sm text-muted-foreground">{m.dosage}</p>}
                </div>
                <SupplyBadge status={m.supply} />
              </div>
              <dl className="mt-3 grid grid-cols-3 gap-3">
                <div>
                  <dt className="text-sm text-muted-foreground">Quantity</dt>
                  <dd className="text-base font-medium">{m.quantity}</dd>
                </div>
                <div>
                  <dt className="text-sm text-muted-foreground">Quality / Type</dt>
                  <dd className="text-base font-medium">{m.form}</dd>
                </div>
                <div>
                  <dt className="text-sm text-muted-foreground">Duration</dt>
                  <dd className="text-base font-medium">{m.duration}</dd>
                </div>
              </dl>
              {m.supply === 'restocked' && m.restockedAt && (
                <p className="mt-3 rounded-md bg-success-soft px-3 py-2 text-sm font-medium text-success">
                  Restocked {formatDateTime(m.restockedAt)} — please collect from the pharmacy.
                </p>
              )}
              <SupplyProgress status={m.supply} />
            </li>
          ))}
        </ul>
      )}
    </Section>
  )
}
