import { Mail, Phone, UserRoundCog } from 'lucide-react'
import type { Coordinator } from '@/lib/types'

export function CoordinatorCard({ coordinator }: { coordinator: Coordinator | undefined }) {
  return (
    <aside aria-labelledby="coordinator-heading" className="rounded-xl border bg-card p-5 md:p-6">
      <div className="flex items-center gap-2 text-sm font-medium uppercase tracking-wide text-muted-foreground">
        <UserRoundCog className="size-4" aria-hidden="true" />
        <h2 id="coordinator-heading">Care Coordinator</h2>
      </div>
      <p className="mt-3 text-xl font-semibold">{coordinator?.name ?? 'Not available'}</p>
      <div className="mt-4 flex flex-col gap-2">
        {coordinator?.phone ? (
          <a
            href={`tel:${coordinator.phone.replace(/\s/g, '')}`}
            className="flex h-11 items-center gap-2 rounded-lg bg-primary px-4 text-base font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            <Phone className="size-4" aria-hidden="true" />
            <span className="sr-only">Call coordinator at</span>
            {coordinator.phone}
          </a>
        ) : (
          <p className="text-base text-muted-foreground">Phone: Not available</p>
        )}
        {coordinator?.email && (
          <a href={`mailto:${coordinator.email}`} className="flex items-center gap-2 break-all text-sm text-primary underline-offset-4 hover:underline">
            <Mail className="size-4 shrink-0" aria-hidden="true" />
            {coordinator.email}
          </a>
        )}
      </div>
    </aside>
  )
}
