'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  Bell,
  CalendarDays,
  HeartPulse,
  House,
  LayoutDashboard,
  LogOut,
  PanelLeftClose,
  PanelLeftOpen,
  Pill,
  Route,
  Settings,
  Siren,
  UserRound,
  Users,
  type LucideIcon,
} from 'lucide-react'
import { initials } from '@/lib/format'
import { cn } from '@/lib/utils'
import type { Session } from '@/lib/types'

interface NavItem {
  href: string
  label: string
  icon: LucideIcon
  badge?: number
}

export function getNav(role: Session['role'], counts: { unread: number; escalations: number }) {
  if (role === 'patient') {
    return {
      main: [
        { href: '/patient', label: 'Dashboard', icon: LayoutDashboard },
        { href: '/patient/appointments', label: 'Appointments', icon: CalendarDays },
        { href: '/patient/medicines', label: 'Medicines', icon: Pill },
        { href: '/patient/home-care', label: 'Home Care', icon: House },
        { href: '/patient/tracker', label: 'Care Tracker', icon: Route },
        { href: '/patient/notifications', label: 'Notifications', icon: Bell, badge: counts.unread },
        { href: '/patient/profile', label: 'My Profile', icon: UserRound },
      ] satisfies NavItem[],
      footer: [{ href: '/patient/settings', label: 'Settings', icon: Settings }] satisfies NavItem[],
    }
  }
  return {
    main: [
      { href: '/coordinator', label: 'Dashboard', icon: LayoutDashboard },
      { href: '/coordinator/patients', label: 'Patients', icon: Users },
      { href: '/coordinator/appointments', label: 'Appointments', icon: CalendarDays },
      { href: '/coordinator/medications', label: 'Medications', icon: Pill },
      { href: '/coordinator/escalations', label: 'Escalations', icon: Siren, badge: counts.escalations },
      { href: '/coordinator/tracking', label: 'Care Tracking', icon: Route },
      { href: '/coordinator/notifications', label: 'Notifications', icon: Bell },
    ] satisfies NavItem[],
    footer: [
      { href: '/coordinator/profile', label: 'Profile', icon: UserRound },
      { href: '/coordinator/settings', label: 'Settings', icon: Settings },
    ] satisfies NavItem[],
  }
}

function isActive(pathname: string, href: string) {
  if (href === '/patient' || href === '/coordinator') return pathname === href
  return pathname === href || pathname.startsWith(`${href}/`)
}

function NavLink({ item, collapsed, onNavigate }: { item: NavItem; collapsed: boolean; onNavigate?: () => void }) {
  const pathname = usePathname()
  const active = isActive(pathname, item.href)
  const Icon = item.icon
  const hasBadge = Boolean(item.badge && item.badge > 0)

  return (
    <li>
      <Link
        href={item.href}
        onClick={onNavigate}
        aria-current={active ? 'page' : undefined}
        title={collapsed ? item.label : undefined}
        className={cn(
          'relative flex h-11 items-center gap-3 rounded-lg px-3 text-base font-medium transition-colors',
          active ? 'bg-primary text-primary-foreground' : 'text-foreground/80 hover:bg-muted hover:text-foreground',
          collapsed && 'justify-center px-0',
        )}
      >
        <Icon className="size-5 shrink-0" aria-hidden="true" />
        <span className={cn('flex-1 truncate', collapsed && 'sr-only')}>{item.label}</span>
        {hasBadge &&
          (collapsed ? (
            <span aria-hidden="true" className="absolute right-2 top-2 size-2.5 rounded-full bg-danger ring-2 ring-card" />
          ) : (
            <span
              className={cn(
                'min-w-6 rounded-full px-1.5 py-0.5 text-center text-xs font-semibold',
                active ? 'bg-primary-foreground text-primary' : 'bg-danger text-primary-foreground',
              )}
            >
              {item.badge}
              <span className="sr-only"> new</span>
            </span>
          ))}
      </Link>
    </li>
  )
}

interface AppSidebarProps {
  session: Session
  counts: { unread: number; escalations: number }
  collapsed: boolean
  onToggleCollapse?: () => void
  onNavigate?: () => void
  onSignOut: () => void
}

export function AppSidebar({ session, counts, collapsed, onToggleCollapse, onNavigate, onSignOut }: AppSidebarProps) {
  const nav = getNav(session.role, counts)
  const roleLabel = session.role === 'patient' ? 'Patient' : 'Care Coordinator'

  return (
    <div className="flex h-full flex-col bg-card">
      <div className={cn('flex h-16 items-center gap-2 border-b px-4', collapsed && 'justify-center px-2')}>
        <span className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-primary text-primary-foreground">
          <HeartPulse className="size-5" aria-hidden="true" />
        </span>
        <div className={cn('min-w-0', collapsed && 'sr-only')}>
          <p className="text-lg font-semibold leading-tight">CareBridge</p>
          <p className="text-xs font-medium text-muted-foreground">{roleLabel}</p>
        </div>
      </div>

      <nav aria-label={`${roleLabel} navigation`} className="flex flex-1 flex-col overflow-y-auto p-3">
        <ul className="flex flex-col gap-1">
          {nav.main.map((item) => (
            <NavLink key={item.href} item={item} collapsed={collapsed} onNavigate={onNavigate} />
          ))}
        </ul>
        <div className="mt-auto border-t pt-3">
          <ul className="flex flex-col gap-1">
            {nav.footer.map((item) => (
              <NavLink key={item.href} item={item} collapsed={collapsed} onNavigate={onNavigate} />
            ))}
            <li>
              <button
                type="button"
                onClick={onSignOut}
                title={collapsed ? 'Logout' : undefined}
                className={cn(
                  'flex h-11 w-full items-center gap-3 rounded-lg px-3 text-base font-medium text-danger transition-colors hover:bg-danger-soft',
                  collapsed && 'justify-center px-0',
                )}
              >
                <LogOut className="size-5 shrink-0" aria-hidden="true" />
                <span className={cn(collapsed && 'sr-only')}>Logout</span>
              </button>
            </li>
          </ul>
        </div>
      </nav>

      <div className={cn('flex items-center gap-3 border-t p-3', collapsed && 'flex-col')}>
        <span
          aria-hidden="true"
          className="flex size-9 shrink-0 items-center justify-center rounded-full bg-accent text-sm font-semibold text-accent-foreground"
        >
          {initials(session.name)}
        </span>
        <p className={cn('min-w-0 flex-1 truncate text-sm font-medium', collapsed && 'sr-only')}>{session.name}</p>
        {onToggleCollapse && (
          <button
            type="button"
            onClick={onToggleCollapse}
            aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            className="flex size-9 shrink-0 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            {collapsed ? <PanelLeftOpen className="size-5" aria-hidden="true" /> : <PanelLeftClose className="size-5" aria-hidden="true" />}
          </button>
        )}
      </div>
    </div>
  )
}
