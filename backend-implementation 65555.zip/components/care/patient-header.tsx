import { CalendarDays, Hospital, Stethoscope, User } from 'lucide-react'
import { formatDate, initials } from '@/lib/format'
import type { Patient } from '@/lib/types'

const NA = 'Not available'

export function PatientHeader({ patient, greeting }: { patient: Patient; greeting?: boolean }) {
  const facts = [
    { icon: User, label: 'Age', value: patient.age ? `${patient.age} years` : NA },
    { icon: Stethoscope, label: 'Diagnosis / Procedure', value: patient.diagnosis ?? NA },
    { icon: CalendarDays, label: 'Discharged', value: formatDate(patient.dischargeDate) ?? NA },
    { icon: Hospital, label: 'Hospital', value: patient.hospital ?? NA },
  ]

  return (
    <div className="rounded-xl border bg-card p-5 md:p-6">
      <div className="flex items-center gap-4">
        <span
          aria-hidden="true"
          className="flex size-14 shrink-0 items-center justify-center rounded-full bg-primary text-lg font-semibold text-primary-foreground"
        >
          {initials(patient.name)}
        </span>
        <div>
          {greeting && <p className="text-sm text-muted-foreground">Welcome back,</p>}
          <h1 className="text-2xl font-semibold leading-tight text-balance md:text-3xl">{patient.name}</h1>
        </div>
      </div>
      <dl className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {facts.map(({ icon: Icon, label, value }) => (
          <div key={label} className="flex items-start gap-2.5">
            <Icon className="mt-0.5 size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
            <div>
              <dt className="text-sm text-muted-foreground">{label}</dt>
              <dd className="text-base font-medium">{value}</dd>
            </div>
          </div>
        ))}
      </dl>
    </div>
  )
}
