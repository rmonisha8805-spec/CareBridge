export function DetailList({ items }: { items: { label: string; value: React.ReactNode }[] }) {
  return (
    <dl className="grid gap-x-6 gap-y-4 sm:grid-cols-2">
      {items.map((item) => (
        <div key={item.label} className="border-b pb-3">
          <dt className="text-sm text-muted-foreground">{item.label}</dt>
          <dd className="mt-0.5 text-base font-medium">{item.value ?? 'Not available'}</dd>
        </div>
      ))}
    </dl>
  )
}
