'use client'

import { BellRing, CalendarDays, House, Pill, type LucideIcon } from 'lucide-react'
import { markNotificationRead } from '@/lib/care-store'
import { formatDateTime } from '@/lib/format'
import { cn } from '@/lib/utils'
import type { CareNotification, NotificationCategory } from '@/lib/types'
import { EmptyState } from './states'

const categoryMeta: Record<NotificationCategory, { label: string; icon: LucideIcon; className: string }> = {
  appointment: { label: 'Appointment', icon: CalendarDays, className: 'bg-info-soft text-info' },
  medicine: { label: 'Medicine', icon: Pill, className: 'bg-success-soft text-success' },
  home_care: { label: 'Home Care', icon: House, className: 'bg-secondary text-primary' },
  update: { label: 'Care Update', icon: BellRing, className: 'bg-warning-soft text-warning' },
}

export function NotificationList({ patientId, notifications, limit }: { patientId: string; notifications: CareNotification[]; limit?: number }) {
  const sorted = [...notifications].sort((a, b) => new Date(b.at).getTime() - new Date(a.at).getTime()).slice(0, limit)
  if (sorted.length === 0) return <EmptyState message="You have no notifications." />

  return (
    <ul className="flex flex-col gap-2">
      {sorted.map((n) => {
        const meta = categoryMeta[n.category]
        const Icon = meta.icon
        return (
          <li key={n.id}>
            <button
              type="button"
              onClick={() => !n.read && markNotificationRead(patientId, n.id)}
              className={cn(
                'flex w-full items-start gap-3 rounded-lg border p-4 text-left transition-colors',
                n.read ? 'bg-background hover:bg-muted/50' : 'border-primary/40 bg-secondary hover:bg-secondary/70',
              )}
            >
              <span className={cn('flex size-10 shrink-0 items-center justify-center rounded-full', meta.className)}>
                <Icon className="size-5" aria-hidden="true" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="flex flex-wrap items-center gap-x-2 gap-y-1">
                  <span className={cn('text-base', n.read ? 'font-medium' : 'font-semibold')}>{n.title}</span>
                  {!n.read && (
                    <span className="rounded-full bg-primary px-2 py-0.5 text-xs font-semibold text-primary-foreground">New</span>
                  )}
                </span>
                <span className="mt-0.5 block text-base text-muted-foreground">{n.message}</span>
                <span className="mt-1.5 block text-sm text-muted-foreground">
                  {meta.label} · {formatDateTime(n.at)}
                </span>
              </span>
              {!n.read && <span className="mt-2 size-2.5 shrink-0 rounded-full bg-primary" aria-label="Unread" />}
            </button>
          </li>
        )
      })}
    </ul>
  )
}
