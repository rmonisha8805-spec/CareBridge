'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { HeartPulse, Menu, X } from 'lucide-react'
import { signOut, useCareData, useSession } from '@/lib/care-store'
import { cn } from '@/lib/utils'
import type { Session } from '@/lib/types'
import { AppSidebar } from './app-sidebar'
import { LoadingState } from './states'

export function RoleLayout({ role, children }: { role: Session['role']; children: React.ReactNode }) {
  const router = useRouter()
  const session = useSession()
  const { data } = useCareData()
  const [collapsed, setCollapsed] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const authorized = session?.role === role

  useEffect(() => {
    if (!authorized) router.replace('/')
  }, [authorized, router])

  useEffect(() => {
    if (!mobileOpen) return
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setMobileOpen(false)
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [mobileOpen])

  if (!session || !authorized) return <LoadingState label="Checking your sign-in..." />

  const patient = session.role === 'patient' ? data?.patients.find((p) => p.id === session.patientId) : undefined
  const counts = {
    unread: patient?.notifications.filter((n) => !n.read).length ?? 0,
    escalations: data?.patients.flatMap((p) => p.escalations).filter((e) => e.status !== 'resolved').length ?? 0,
  }

  async function handleSignOut() {
    await signOut()
    router.replace('/')
  }

  return (
    <div className="min-h-screen md:flex">
      <aside
        className={cn(
          'sticky top-0 hidden h-screen shrink-0 border-r transition-[width] duration-200 md:block',
          collapsed ? 'w-[72px]' : 'w-64',
        )}
      >
        <AppSidebar
          session={session}
          counts={counts}
          collapsed={collapsed}
          onToggleCollapse={() => setCollapsed((c) => !c)}
          onSignOut={handleSignOut}
        />
      </aside>

      <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b bg-card/95 px-4 backdrop-blur md:hidden">
        <div className="flex items-center gap-2 font-semibold">
          <span className="flex size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <HeartPulse className="size-4" aria-hidden="true" />
          </span>
          CareBridge
        </div>
        <button
          type="button"
          onClick={() => setMobileOpen(true)}
          aria-label="Open menu"
          aria-expanded={mobileOpen}
          className="relative flex size-10 items-center justify-center rounded-lg border"
        >
          <Menu className="size-5" aria-hidden="true" />
          {(counts.unread > 0 || (role === 'coordinator' && counts.escalations > 0)) && (
            <span aria-hidden="true" className="absolute right-1.5 top-1.5 size-2 rounded-full bg-danger" />
          )}
        </button>
      </header>

      {mobileOpen && (
        <div className="fixed inset-0 z-40 md:hidden" role="dialog" aria-modal="true" aria-label="Navigation menu">
          <button type="button" aria-label="Close menu" className="absolute inset-0 bg-foreground/40" onClick={() => setMobileOpen(false)} />
          <div className="relative h-full w-72 max-w-[85%] shadow-xl">
            <button
              type="button"
              onClick={() => setMobileOpen(false)}
              aria-label="Close menu"
              className="absolute right-3 top-3 z-10 flex size-10 items-center justify-center rounded-lg text-muted-foreground hover:bg-muted"
            >
              <X className="size-5" aria-hidden="true" />
            </button>
            <AppSidebar
              session={session}
              counts={counts}
              collapsed={false}
              onNavigate={() => setMobileOpen(false)}
              onSignOut={handleSignOut}
            />
          </div>
        </div>
      )}

      <main className="min-w-0 flex-1">
        <div className="mx-auto max-w-6xl px-4 py-6 md:px-8 md:py-8">{children}</div>
      </main>
    </div>
  )
}
