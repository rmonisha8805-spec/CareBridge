import {
  AlertTriangle,
  BadgeCheck,
  CheckCircle2,
  CircleDot,
  Clock,
  Hourglass,
  PackageCheck,
  PackageX,
  RefreshCw,
  ShoppingBag,
  XCircle,
  type LucideIcon,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import type { Escalation, SupplyStatus, TaskStatus } from '@/lib/types'

type Tone = 'success' | 'warning' | 'info' | 'danger' | 'escalated' | 'neutral'

const toneClasses: Record<Tone, string> = {
  success: 'bg-success-soft text-success border-success/25',
  warning: 'bg-warning-soft text-warning border-warning/25',
  info: 'bg-info-soft text-info border-info/25',
  danger: 'bg-danger-soft text-danger border-danger/25',
  escalated: 'bg-escalated-soft text-escalated border-escalated/25',
  neutral: 'bg-muted text-muted-foreground border-border',
}

interface BadgeConfig {
  label: string
  icon: LucideIcon
  tone: Tone
}

export const taskStatusConfig: Record<TaskStatus, BadgeConfig> = {
  pending: { label: 'Pending', icon: Clock, tone: 'neutral' },
  in_progress: { label: 'In Progress', icon: CircleDot, tone: 'info' },
  verification_pending: { label: 'Verification Pending', icon: Hourglass, tone: 'warning' },
  completed: { label: 'Completed', icon: CheckCircle2, tone: 'success' },
  failed: { label: 'Failed', icon: XCircle, tone: 'danger' },
  escalated: { label: 'Escalated', icon: AlertTriangle, tone: 'escalated' },
}

export const supplyStatusConfig: Record<SupplyStatus, BadgeConfig> = {
  available: { label: 'Available', icon: PackageCheck, tone: 'info' },
  out_of_stock: { label: 'Out of Stock', icon: PackageX, tone: 'danger' },
  restocking: { label: 'Restocking', icon: RefreshCw, tone: 'warning' },
  restocked: { label: 'Restocked · Ready to Collect', icon: PackageCheck, tone: 'success' },
  collected: { label: 'Collected', icon: ShoppingBag, tone: 'neutral' },
  verified: { label: 'Verified', icon: BadgeCheck, tone: 'success' },
}

const escalationStatusConfig: Record<Escalation['status'], BadgeConfig> = {
  escalated: { label: 'Escalated', icon: AlertTriangle, tone: 'escalated' },
  in_review: { label: 'Coordinator Acting', icon: CircleDot, tone: 'info' },
  resolved: { label: 'Resolved', icon: CheckCircle2, tone: 'success' },
}

export function Badge({ config, className }: { config: BadgeConfig; className?: string }) {
  const Icon = config.icon
  return (
    <span
      className={cn(
        'inline-flex shrink-0 items-center gap-1.5 rounded-full border px-2.5 py-1 text-sm font-medium leading-none',
        toneClasses[config.tone],
        className,
      )}
    >
      <Icon className="size-4" aria-hidden="true" />
      {config.label}
    </span>
  )
}

export function StatusBadge({ status, className }: { status: TaskStatus; className?: string }) {
  return <Badge config={taskStatusConfig[status]} className={className} />
}

export function SupplyBadge({ status, className }: { status: SupplyStatus; className?: string }) {
  return <Badge config={supplyStatusConfig[status]} className={className} />
}

export function EscalationStatusBadge({ status }: { status: Escalation['status'] }) {
  return <Badge config={escalationStatusConfig[status]} />
}
