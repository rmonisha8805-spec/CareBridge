import type { LucideIcon } from 'lucide-react'
import { cn } from '@/lib/utils'

interface SectionProps {
  id: string
  title: string
  description?: string
  icon: LucideIcon
  action?: React.ReactNode
  children: React.ReactNode
  className?: string
}

export function Section({ id, title, description, icon: Icon, action, children, className }: SectionProps) {
  return (
    <section aria-labelledby={id} className={cn('rounded-xl border bg-card p-5 md:p-6', className)}>
      <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <span className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-secondary text-primary">
            <Icon className="size-5" aria-hidden="true" />
          </span>
          <div>
            <h2 id={id} className="text-lg font-semibold leading-tight text-balance">
              {title}
            </h2>
            {description && <p className="mt-1 text-sm text-muted-foreground">{description}</p>}
          </div>
        </div>
        {action}
      </div>
      {children}
    </section>
  )
}
