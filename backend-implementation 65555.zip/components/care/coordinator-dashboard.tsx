import Link from 'next/link'
import { Activity, AlertTriangle, ChevronRight, Siren, Users, XCircle } from 'lucide-react'
import type { CareData, Session } from '@/lib/types'
import { taskTypeMeta } from './care-tasks'
import { EscalationCard } from './escalation-card'
import { Section } from './section'
import { EmptyState } from './states'
import { StatusBadge } from './status-badge'

export function CoordinatorDashboard({ data, session }: { data: CareData; session: Session }) {
  const { patients } = data
  const allTasks = patients.flatMap((p) => p.tasks)
  const openEscalations = patients.flatMap((p) => p.escalations.filter((e) => e.status !== 'resolved').map((e) => ({ patient: p, escalation: e })))
  const needsAttention = (id: string) => patients.find((p) => p.id === id)!.tasks.some((t) => ['failed', 'escalated', 'verification_pending'].includes(t.status))

  const stats = [
    { label: 'Patients', value: patients.length, icon: Users, className: 'text-primary bg-secondary' },
    { label: 'Active care tasks', value: allTasks.filter((t) => t.status !== 'completed').length, icon: Activity, className: 'text-info bg-info-soft' },
    { label: 'Failed tasks', value: allTasks.filter((t) => t.status === 'failed').length, icon: XCircle, className: 'text-danger bg-danger-soft' },
    { label: 'Open escalations', value: openEscalations.length, icon: AlertTriangle, className: 'text-escalated bg-escalated-soft' },
  ]

  const sortedPatients = [...patients].sort((a, b) => Number(needsAttention(b.id)) - Number(needsAttention(a.id)))

  return (
    <div className="flex flex-col gap-6">
      <div>
        <p className="text-sm text-muted-foreground">Good day, {session.name}</p>
        <h1 className="text-2xl font-semibold md:text-3xl">Coordinator Dashboard</h1>
      </div>

      <ul className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {stats.map(({ label, value, icon: Icon, className }) => (
          <li key={label} className="flex items-center gap-3 rounded-xl border bg-card p-4">
            <span className={`flex size-10 items-center justify-center rounded-lg ${className}`}>
              <Icon className="size-5" aria-hidden="true" />
            </span>
            <div>
              <p className="text-2xl font-semibold leading-none">{value}</p>
              <p className="mt-1 text-sm text-muted-foreground">{label}</p>
            </div>
          </li>
        ))}
      </ul>

      <Section id="needs-attention" title="Needs Your Attention" description="Escalated tasks waiting for a coordinator decision." icon={Siren}>
        {openEscalations.length === 0 ? (
          <EmptyState message="No open escalations. Everything is on track." />
        ) : (
          <div className="grid gap-4 lg:grid-cols-2">
            {openEscalations.map(({ patient, escalation }) => (
              <EscalationCard
                key={escalation.id}
                patient={patient}
                escalation={escalation}
                coordinatorName={session.name}
                showPatientLink
              />
            ))}
          </div>
        )}
      </Section>

      <Section id="patients" title="Patients" description="Care status for every patient you coordinate." icon={Users}>
        {patients.length === 0 ? (
          <EmptyState message="No patients assigned." />
        ) : (
          <ul className="flex flex-col divide-y rounded-lg border">
            {sortedPatients.map((p) => (
              <li key={p.id}>
                <Link
                  href={`/coordinator/patients/${p.id}`}
                  className="flex flex-col gap-3 p-4 transition-colors hover:bg-muted/50 md:flex-row md:items-center md:justify-between"
                >
                  <div className="min-w-0">
                    <p className="flex items-center gap-2 text-base font-semibold">
                      {p.name}
                      {needsAttention(p.id) && (
                        <span className="rounded-full bg-escalated-soft px-2 py-0.5 text-xs font-medium text-escalated">Needs attention</span>
                      )}
                    </p>
                    <p className="text-sm text-muted-foreground">{p.diagnosis ?? 'Diagnosis not available'}</p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {p.tasks.map((t) => (
                      <span key={t.id} className="flex items-center gap-1.5">
                        <span className="text-sm text-muted-foreground">{taskTypeMeta[t.type].label}:</span>
                        <StatusBadge status={t.status} />
                      </span>
                    ))}
                    <ChevronRight className="ml-1 hidden size-5 text-muted-foreground md:block" aria-hidden="true" />
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </Section>
    </div>
  )
}
