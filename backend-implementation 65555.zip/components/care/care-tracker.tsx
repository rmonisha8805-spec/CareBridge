import { AlertTriangle, ArrowDown, Check, Route, X } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { CareTask, TaskStatus, TaskType } from '@/lib/types'
import { Section } from './section'
import { taskStatusConfig } from './status-badge'

interface Stage {
  label: string
  status: TaskStatus
}

export function deriveStages(tasks: CareTask[]): Stage[] {
  const typed: [string, TaskType][] = [
    ['Appointment', 'appointment'],
    ['Medicine', 'medicine'],
    ['Home Care', 'home_care'],
  ]
  const taskStages = typed
    .map(([label, type]) => ({ label, status: tasks.find((t) => t.type === type)?.status ?? null }))
    .filter((s): s is Stage => s.status !== null)

  const allDone = tasks.length > 0 && tasks.every((t) => t.status === 'completed')
  const anyCompleted = tasks.some((t) => t.status === 'completed' || t.status === 'verification_pending')

  return [
    { label: 'Care Request', status: tasks.length > 0 ? 'completed' : 'pending' },
    ...taskStages,
    { label: 'Verification', status: allDone ? 'completed' : anyCompleted ? 'verification_pending' : 'pending' },
    { label: 'Completed', status: allDone ? 'completed' : 'pending' },
  ]
}

const markerClasses: Record<TaskStatus, string> = {
  completed: 'border-success bg-success text-primary-foreground',
  in_progress: 'border-info bg-info-soft text-info',
  verification_pending: 'border-warning bg-warning-soft text-warning',
  pending: 'border-border bg-card text-muted-foreground',
  failed: 'border-danger bg-danger text-primary-foreground',
  escalated: 'border-escalated bg-escalated text-primary-foreground',
}

const rowClasses: Record<TaskStatus, string> = {
  completed: 'border-success/40 bg-success-soft',
  in_progress: 'border-info/40 bg-info-soft/60',
  verification_pending: 'border-warning/40 bg-warning-soft/60',
  pending: 'bg-background',
  failed: 'border-danger/40 bg-danger-soft',
  escalated: 'border-escalated/40 bg-escalated-soft',
}

function Marker({ status }: { status: TaskStatus }) {
  return (
    <span aria-hidden="true" className={cn('relative z-10 flex size-9 shrink-0 items-center justify-center rounded-full border-2', markerClasses[status])}>
      {status === 'completed' && <Check className="size-4" />}
      {status === 'failed' && <X className="size-4" />}
      {status === 'escalated' && <AlertTriangle className="size-4" />}
      {(status === 'in_progress' || status === 'verification_pending') && <span className="size-2.5 rounded-full bg-current" />}
    </span>
  )
}

function Progress({ stages }: { stages: Stage[] }) {
  const done = stages.filter((s) => s.status === 'completed').length
  const pct = Math.round((done / stages.length) * 100)
  return (
    <div className="mb-6">
      <div className="mb-2 flex items-baseline justify-between text-sm text-muted-foreground">
        <span>Overall progress</span>
        <span>
          <span className="text-lg font-semibold text-foreground">{done}</span> of {stages.length} stages complete
        </span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-muted" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100} aria-label="Overall care progress">
        <div className="h-full rounded-full bg-success transition-all" style={{ width: `${pct}%` }} />
      </div>
    </div>
  )
}

export function CareTracker({ tasks, variant = 'compact', title = 'Care Tracker' }: { tasks: CareTask[]; variant?: 'compact' | 'flow'; title?: string }) {
  const stages = deriveStages(tasks)
  const currentIndex = stages.findIndex((s) => s.status !== 'completed')

  return (
    <Section id={`care-tracker-${variant}`} title={title} description="Where you are right now in the care journey." icon={Route}>
      <Progress stages={stages} />
      {variant === 'flow' ? (
        <ol className="mx-auto flex max-w-lg flex-col" aria-label="Care journey flow map">
          {stages.map((stage, i) => (
            <li key={stage.label}>
              <div className={cn('flex items-center gap-4 rounded-xl border p-4', rowClasses[stage.status], i === currentIndex && 'ring-2 ring-primary/40')}>
                <Marker status={stage.status} />
                <div className="flex-1">
                  <p className={cn('text-lg font-semibold', stage.status === 'completed' && 'text-success')}>{stage.label}</p>
                  <p className="text-sm text-muted-foreground">
                    {taskStatusConfig[stage.status].label}
                    {i === currentIndex && ' · You are here'}
                  </p>
                </div>
              </div>
              {i < stages.length - 1 && (
                <ArrowDown className={cn('mx-auto my-1.5 size-5', stage.status === 'completed' ? 'text-success' : 'text-muted-foreground/50')} aria-hidden="true" />
              )}
            </li>
          ))}
        </ol>
      ) : (
        <ol className="flex flex-col gap-0 md:flex-row">
          {stages.map((stage, i) => (
            <li key={stage.label} className="relative flex flex-1 gap-3 pb-5 md:flex-col md:items-center md:pb-0 md:text-center">
              {i < stages.length - 1 && (
                <span
                  aria-hidden="true"
                  className={cn(
                    'absolute left-[17px] top-9 bottom-0 w-0.5 md:left-[calc(50%+18px)] md:right-[calc(-50%+18px)] md:top-[17px] md:bottom-auto md:h-0.5 md:w-auto',
                    stage.status === 'completed' ? 'bg-success' : 'bg-border',
                  )}
                />
              )}
              <Marker status={stage.status} />
              <div className="pt-1 md:pt-0">
                <p className={cn('text-base font-semibold', stage.status === 'completed' && 'text-success')}>{stage.label}</p>
                <p className="text-sm text-muted-foreground">{taskStatusConfig[stage.status].label}</p>
              </div>
            </li>
          ))}
        </ol>
      )}
    </Section>
  )
}
