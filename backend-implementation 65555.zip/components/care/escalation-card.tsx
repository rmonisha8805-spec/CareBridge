'use client'

import { useState } from 'react'
import Link from 'next/link'
import { ArrowRight, CalendarX, CircleAlert, PillBottle, Zap } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { takeOverEscalation } from '@/lib/care-store'
import { formatDate, formatDateTime, formatTime } from '@/lib/format'
import { cn } from '@/lib/utils'
import type { Escalation, Patient } from '@/lib/types'
import { ResolutionPanel } from './resolution-panel'
import { EscalationStatusBadge, SupplyBadge } from './status-badge'

export const escalationCategoryMeta = {
  follow_up_appointment: { label: 'Follow-up Appointment', icon: CalendarX },
  medication: { label: 'Medication', icon: PillBottle },
} as const

function Fact({ label, children, wide }: { label: string; children: React.ReactNode; wide?: boolean }) {
  return (
    <div className={cn(wide && 'sm:col-span-2')}>
      <dt className="text-sm text-muted-foreground">{label}</dt>
      <dd className="text-base font-semibold">{children}</dd>
    </div>
  )
}

export function EscalationFacts({ patient, escalation }: { patient: Patient; escalation: Escalation }) {
  const appointment = patient.appointments.find((a) => a.id === escalation.appointmentId)
  const medicine = patient.medicines.find((m) => m.id === escalation.medicineId)

  return (
    <dl className="grid gap-4 sm:grid-cols-2">
      <Fact label="Patient">{patient.name}</Fact>
      {escalation.category === 'follow_up_appointment' ? (
        <>
          <Fact label="Doctor">{appointment?.doctor ?? 'Not available'}</Fact>
          <Fact label="Date">{formatDate(appointment?.at ?? null) ?? 'Not available'}</Fact>
          <Fact label="Time">{formatTime(appointment?.at ?? null) ?? 'Not available'}</Fact>
        </>
      ) : (
        <>
          <Fact label="Medicine">{medicine ? `${medicine.name} · ${medicine.quantity}` : 'Not available'}</Fact>
          <Fact label="Supply">{medicine ? <SupplyBadge status={medicine.supply} className="mt-1" /> : 'Not available'}</Fact>
          <Fact label="Notification">
            <span className="text-success">Sent ({escalation.notificationHistory.length})</span>
          </Fact>
          <Fact label="Collection">
            <span className="text-danger">{medicine?.supply === 'collected' ? 'Completed' : 'Not Completed'}</span>
          </Fact>
        </>
      )}
      <div className="sm:col-span-2">
        <dt className="text-sm text-muted-foreground">Reason</dt>
        <dd className="mt-1 flex items-start gap-2 rounded-md bg-danger-soft px-3 py-2 text-base font-medium text-danger">
          <CircleAlert className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
          {escalation.reason}
        </dd>
      </div>
    </dl>
  )
}

interface EscalationCardProps {
  patient: Patient
  escalation: Escalation
  coordinatorName: string
  showPatientLink?: boolean
}

export function EscalationCard({ patient, escalation, coordinatorName, showPatientLink }: EscalationCardProps) {
  const [open, setOpen] = useState(false)
  const resolved = escalation.status === 'resolved'
  const meta = escalationCategoryMeta[escalation.category]
  const Icon = meta.icon

  async function handleAct() {
    setOpen(true)
    await takeOverEscalation(patient.id, escalation.id, coordinatorName)
  }

  return (
    <article
      aria-label={`${meta.label} escalation for ${patient.name}`}
      className={cn('rounded-xl border bg-card', resolved ? 'border-success/30' : 'border-escalated/40', open && 'lg:col-span-2')}
    >
      <div className={cn('h-1 rounded-t-xl', resolved ? 'bg-success' : 'bg-escalated')} aria-hidden="true" />
      <div className="p-5">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <p className="flex items-center gap-2 text-base font-semibold">
            <Icon className="size-5 text-escalated" aria-hidden="true" />
            {meta.label} Escalation
          </p>
          <EscalationStatusBadge status={escalation.status} />
        </div>
        <EscalationFacts patient={patient} escalation={escalation} />
        {escalation.takenOverAt && <p className="mt-4 text-sm text-muted-foreground">Coordinator took over {formatDateTime(escalation.takenOverAt)}</p>}
        {escalation.resolvedAt && <p className="mt-1 text-sm font-medium text-success">Resolved {formatDateTime(escalation.resolvedAt)}</p>}

        <div className="mt-5 flex flex-wrap gap-2">
          {!resolved && !open && (
            <Button onClick={handleAct} className="h-11 px-6 text-base">
              <Zap aria-hidden="true" />
              Act
            </Button>
          )}
          {showPatientLink && (
            <Link
              href={`/coordinator/patients/${patient.id}`}
              className="inline-flex h-11 items-center gap-2 rounded-lg border px-4 text-base font-medium transition-colors hover:bg-muted"
            >
              View patient
              <ArrowRight className="size-4" aria-hidden="true" />
            </Link>
          )}
        </div>
      </div>
      {open && !resolved && <ResolutionPanel patient={patient} escalation={escalation} onClose={() => setOpen(false)} />}
    </article>
  )
}
