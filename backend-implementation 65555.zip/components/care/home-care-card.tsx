'use client'

import { useState } from 'react'
import { ArrowDown, Check, CheckCircle2, Clock, Hourglass, House, UserRound, UserRoundCheck } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { confirmHomeVisit, markStaffArrival } from '@/lib/care-store'
import { formatDateTime } from '@/lib/format'
import { cn } from '@/lib/utils'
import type { CareTask, HomeCare } from '@/lib/types'
import { Section } from './section'
import { EmptyState } from './states'
import { Badge, StatusBadge } from './status-badge'

interface HomeCareCardProps {
  patientId: string
  homeCare: HomeCare | null
  task: CareTask | undefined
  viewer: 'patient' | 'coordinator'
}

function FlowStep({ label, done, current }: { label: string; done: boolean; current: boolean }) {
  return (
    <li
      className={cn(
        'flex items-center gap-3 rounded-lg border px-3 py-2.5 text-base font-medium',
        done && 'border-success/30 bg-success-soft text-success',
        current && !done && 'border-primary/40 bg-secondary text-foreground',
        !done && !current && 'bg-background text-muted-foreground',
      )}
    >
      <span
        aria-hidden="true"
        className={cn(
          'flex size-6 shrink-0 items-center justify-center rounded-full border-2',
          done ? 'border-success bg-success text-primary-foreground' : current ? 'border-primary' : 'border-border',
        )}
      >
        {done && <Check className="size-3.5" />}
      </span>
      {label}
      <span className="sr-only">{done ? ' — done' : current ? ' — current step' : ' — upcoming'}</span>
    </li>
  )
}

export function HomeCareFlow({ homeCare, completed }: { homeCare: HomeCare; completed: boolean }) {
  const arrived = Boolean(homeCare.arrivedAt)
  const confirmed = Boolean(homeCare.confirmedAt)
  const steps = [
    { label: `Nurse / Field Worker assigned — ${homeCare.staffName}`, done: true },
    { label: "Reached Patient's Home — Staff Arrival Marked", done: arrived },
    { label: 'Patient Confirms Visit — Patient Attendance Marked', done: confirmed },
    { label: 'Completed', done: completed },
  ]
  const currentIndex = steps.findIndex((s) => !s.done)

  return (
    <ol className="flex flex-col" aria-label="Home care visit flow">
      {steps.map((s, i) => (
        <div key={s.label}>
          <FlowStep label={s.label} done={s.done} current={i === currentIndex} />
          {i < steps.length - 1 && (
            <ArrowDown className={cn('mx-auto my-1 size-4', s.done ? 'text-success' : 'text-muted-foreground/60')} aria-hidden="true" />
          )}
        </div>
      ))}
    </ol>
  )
}

function AttendanceCard({
  number,
  title,
  who,
  prompt,
  done,
  doneLabel,
  doneAt,
  waitingLabel,
  action,
}: {
  number: 1 | 2
  title: string
  who: string
  prompt: string
  done: boolean
  doneLabel: string
  doneAt: string | null
  waitingLabel: string
  action?: React.ReactNode
}) {
  return (
    <div className={cn('flex flex-col gap-3 rounded-xl border p-4', done ? 'border-success/40 bg-success-soft/50' : 'bg-background')}>
      <div className="flex items-center gap-2">
        <span className="rounded-md bg-muted px-2 py-0.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          Attendance {number}
        </span>
        <span className="text-sm text-muted-foreground">{who}</span>
      </div>
      <div>
        <h3 className="text-lg font-semibold">{title}</h3>
        <p className="mt-0.5 text-base text-muted-foreground">{`“${prompt}”`}</p>
      </div>
      {done ? (
        <div className="flex flex-col gap-1">
          <Badge config={{ label: doneLabel, icon: CheckCircle2, tone: 'success' }} className="self-start" />
          {doneAt && <p className="text-sm text-muted-foreground">{formatDateTime(doneAt)}</p>}
        </div>
      ) : (
        <div className="flex flex-col items-start gap-3">
          <Badge config={{ label: waitingLabel, icon: number === 1 ? Clock : Hourglass, tone: 'warning' }} />
          {action}
        </div>
      )}
    </div>
  )
}

export function HomeCareCard({ patientId, homeCare, task, viewer }: HomeCareCardProps) {
  const [pending, setPending] = useState(false)

  async function run(action: (id: string) => Promise<unknown>) {
    setPending(true)
    await action(patientId)
    setPending(false)
  }

  if (!homeCare || !task) {
    return (
      <Section id="home-care" title="Home Care Visit" icon={House}>
        <EmptyState message="No home care visit is scheduled." />
      </Section>
    )
  }

  const arrived = Boolean(homeCare.arrivedAt)
  const confirmed = Boolean(homeCare.confirmedAt)
  const completed = task.status === 'completed'

  return (
    <Section id="home-care" title="Home Care Visit" description={homeCare.purpose ?? undefined} icon={House} action={<StatusBadge status={task.status} />}>
      <div className="mb-5 flex items-center gap-3 rounded-lg bg-muted/60 p-3">
        <span className="flex size-10 items-center justify-center rounded-full bg-card text-primary">
          <UserRound className="size-5" aria-hidden="true" />
        </span>
        <div>
          <p className="text-sm text-muted-foreground">{homeCare.staffRole}</p>
          <p className="text-base font-semibold">{homeCare.staffName}</p>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_1.2fr]">
        <div>
          <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted-foreground">Visit flow</h3>
          <HomeCareFlow homeCare={homeCare} completed={completed} />
        </div>

        <div className="flex flex-col gap-4">
          <AttendanceCard
            number={1}
            who="Staff / Nurse"
            title="Staff Arrival"
            prompt="I have reached the patient's home."
            done={arrived}
            doneLabel="Staff Arrived at Patient's Home"
            doneAt={homeCare.arrivedAt}
            waitingLabel="Waiting for staff to arrive"
            action={
              viewer === 'coordinator' ? (
                <Button onClick={() => run(markStaffArrival)} disabled={pending} className="h-11 px-4 text-base">
                  <UserRoundCheck aria-hidden="true" />
                  Mark Arrival
                </Button>
              ) : (
                <p className="text-sm text-muted-foreground">{homeCare.staffName} will mark arrival when they reach your home.</p>
              )
            }
          />
          <AttendanceCard
            number={2}
            who="Patient"
            title="Patient Confirmation"
            prompt="The nurse / worker visited my home."
            done={confirmed}
            doneLabel="Patient Confirmed Visit"
            doneAt={homeCare.confirmedAt}
            waitingLabel={arrived ? 'Waiting for patient confirmation' : 'Available after staff arrival'}
            action={
              viewer === 'patient' && arrived ? (
                <Button onClick={() => run(confirmHomeVisit)} disabled={pending} className="h-11 px-4 text-base">
                  <CheckCircle2 aria-hidden="true" />
                  Confirm Visit
                </Button>
              ) : undefined
            }
          />
        </div>
      </div>
    </Section>
  )
}
