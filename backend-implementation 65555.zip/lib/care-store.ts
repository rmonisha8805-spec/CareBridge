'use client'

import useSWR, { mutate } from 'swr'
import { fetchCareData } from './api'
import type { CareData, Escalation, Patient, Session, TaskStatus, TaskType, TimelineEvent } from './types'

const CARE_KEY = 'care-data'
const SESSION_KEY = 'session'

export function useCareData() {
  return useSWR<CareData>(CARE_KEY, fetchCareData, {
    revalidateOnFocus: false,
    revalidateOnReconnect: false,
    revalidateIfStale: false,
  })
}

export function useSession() {
  const { data } = useSWR<Session | null>(SESSION_KEY, null)
  return data ?? null
}

export function signIn(session: Session) {
  return mutate(SESSION_KEY, session, { revalidate: false })
}

export function signOut() {
  return mutate(SESSION_KEY, null, { revalidate: false })
}

function nowIso() {
  return new Date().toISOString()
}

function makeEvent(event: Omit<TimelineEvent, 'id' | 'at'>): TimelineEvent {
  return { ...event, id: `ev-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, at: nowIso() }
}

function updatePatient(patientId: string, updater: (patient: Patient) => Patient) {
  return mutate<CareData>(
    CARE_KEY,
    (current) =>
      current && {
        ...current,
        patients: current.patients.map((p) => (p.id === patientId ? updater(structuredClone(p)) : p)),
      },
    { revalidate: false },
  )
}

function setTaskStatus(patient: Patient, type: TaskType, status: TaskStatus) {
  patient.tasks = patient.tasks.map((t) => (t.type === type ? { ...t, status } : t))
}

function escalationTaskType(e: Escalation): TaskType {
  return e.category === 'medication' ? 'medicine' : 'appointment'
}

function withEscalation(patientId: string, escalationId: string, updater: (p: Patient, e: Escalation) => void) {
  return updatePatient(patientId, (p) => {
    const esc = p.escalations.find((e) => e.id === escalationId)
    if (esc) updater(p, esc)
    return p
  })
}

export function markStaffArrival(patientId: string) {
  return updatePatient(patientId, (p) => {
    if (!p.homeCare || p.homeCare.arrivedAt) return p
    p.homeCare.arrivedAt = nowIso()
    setTaskStatus(p, 'home_care', 'in_progress')
    p.timeline.push(makeEvent({ title: 'Staff arrival marked', description: `${p.homeCare.staffName} reached the patient's home.`, kind: 'success', taskType: 'home_care' }))
    return p
  })
}

export function confirmHomeVisit(patientId: string) {
  return updatePatient(patientId, (p) => {
    if (!p.homeCare?.arrivedAt || p.homeCare.confirmedAt) return p
    p.homeCare.confirmedAt = nowIso()
    setTaskStatus(p, 'home_care', 'completed')
    p.timeline.push(makeEvent({ title: 'Patient confirmed visit', description: 'Patient attendance marked. Home care completed.', kind: 'success', taskType: 'home_care' }))
    p.notifications = p.notifications.map((n) => (n.category === 'home_care' ? { ...n, read: true } : n))
    return p
  })
}

export function markNotificationRead(patientId: string, notificationId: string) {
  return updatePatient(patientId, (p) => {
    p.notifications = p.notifications.map((n) => (n.id === notificationId ? { ...n, read: true } : n))
    return p
  })
}

export function markAllNotificationsRead(patientId: string) {
  return updatePatient(patientId, (p) => {
    p.notifications = p.notifications.map((n) => ({ ...n, read: true }))
    return p
  })
}

export function takeOverEscalation(patientId: string, escalationId: string, coordinatorName: string) {
  return withEscalation(patientId, escalationId, (p, e) => {
    if (e.takenOverAt) return
    e.takenOverAt = nowIso()
    e.status = 'in_review'
    e.previousActions.push(`Coordinator ${coordinatorName} took over`)
    p.timeline.push(makeEvent({ title: 'Coordinator took over', description: `${coordinatorName} took over: ${e.taskName}.`, kind: 'coordinator', taskType: escalationTaskType(e) }))
  })
}

export function contactPatient(patientId: string, escalationId: string) {
  return withEscalation(patientId, escalationId, (p, e) => {
    e.previousActions.push('Patient contacted by phone')
    p.timeline.push(makeEvent({ title: 'Patient contacted', description: `Coordinator called ${p.name} about ${e.taskName}.`, kind: 'coordinator', taskType: escalationTaskType(e) }))
  })
}

export function sendMedicineReminder(patientId: string, escalationId: string) {
  return withEscalation(patientId, escalationId, (p, e) => {
    const medicine = p.medicines.find((m) => m.id === e.medicineId)
    const at = nowIso()
    e.notificationHistory.push({ at, label: 'Coordinator reminder sent' })
    e.previousActions.push('Coordinator sent reminder')
    p.notifications.unshift({
      id: `n-${Date.now()}`,
      at,
      category: 'medicine',
      title: `Reminder: collect ${medicine?.name ?? 'your medicine'}`,
      message: 'Your coordinator reminds you that your medicine is ready for collection at the pharmacy.',
      read: false,
    })
    p.timeline.push(makeEvent({ title: 'Reminder sent', description: `Coordinator reminder sent for ${medicine?.name ?? e.taskName}.`, kind: 'notification', taskType: 'medicine' }))
  })
}

export function rescheduleAppointment(patientId: string, escalationId: string, when: string) {
  return withEscalation(patientId, escalationId, (p, e) => {
    const label = new Date(when).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })
    const original = p.appointments.find((a) => a.id === e.appointmentId)
    e.previousActions.push(`Rescheduled to ${label}`)
    if (original) {
      original.status = 'rescheduled'
      p.appointments.push({
        ...original,
        id: `a-${Date.now()}`,
        at: new Date(when).toISOString(),
        status: 'scheduled',
        attendance: 'upcoming',
      })
    }
    p.tasks = p.tasks.map((t) => (t.id === e.taskId ? { ...t, status: 'in_progress', detail: `${original?.doctor ?? 'Doctor'} · Rescheduled to ${label}` } : t))
    p.notifications.unshift({
      id: `n-${Date.now()}`,
      at: nowIso(),
      category: 'appointment',
      title: 'Appointment rescheduled',
      message: `${e.taskName} with ${original?.doctor ?? 'your doctor'} is now on ${label}.`,
      read: false,
    })
    p.timeline.push(makeEvent({ title: 'Appointment rescheduled', description: `${e.taskName} rescheduled to ${label}.`, kind: 'coordinator', taskType: 'appointment' }))
  })
}

export function resolveEscalation(patientId: string, escalationId: string, note: string) {
  return withEscalation(patientId, escalationId, (p, e) => {
    e.status = 'resolved'
    e.resolvedAt = nowIso()
    e.previousActions.push('Resolved by coordinator')
    if (e.category === 'medication') {
      p.medicines = p.medicines.map((m) => (m.id === e.medicineId ? { ...m, supply: 'collected' } : m))
      setTaskStatus(p, 'medicine', p.medicines.every((m) => m.supply === 'collected' || m.supply === 'verified') ? 'completed' : 'in_progress')
    } else {
      const hasUpcoming = p.appointments.some((a) => a.status === 'scheduled')
      setTaskStatus(p, 'appointment', hasUpcoming ? 'in_progress' : 'completed')
    }
    p.timeline.push(makeEvent({ title: 'Resolution', description: `${e.taskName} resolved.${note ? ` ${note}` : ''}`, kind: 'success', taskType: escalationTaskType(e) }))
  })
}
