export type TaskStatus =
  | 'pending'
  | 'in_progress'
  | 'verification_pending'
  | 'completed'
  | 'failed'
  | 'escalated'

export type TaskType = 'appointment' | 'medicine' | 'home_care'

export type SupplyStatus = 'available' | 'out_of_stock' | 'restocking' | 'restocked' | 'collected' | 'verified'

export type TimelineKind = 'info' | 'success' | 'failed' | 'escalated' | 'coordinator' | 'notification'

export interface Coordinator {
  id: string
  name: string
  phone: string | null
  email: string | null
}

export interface CareTask {
  id: string
  type: TaskType
  title: string
  status: TaskStatus
  detail: string | null
}

export interface Medicine {
  id: string
  name: string
  quantity: string
  form: string
  dosage: string | null
  duration: string
  supply: SupplyStatus
  restockedAt: string | null
}

export interface HomeCare {
  staffName: string
  staffRole: string
  purpose: string | null
  arrivedAt: string | null
  confirmedAt: string | null
}

export type AppointmentStatus = 'scheduled' | 'completed' | 'missed' | 'rescheduled'
export type AttendanceStatus = 'upcoming' | 'attended' | 'not_attended'

export interface Appointment {
  id: string
  title: string
  doctor: string
  department: string | null
  at: string
  status: AppointmentStatus
  attendance: AttendanceStatus
  followUp: string | null
}

export type NotificationCategory = 'appointment' | 'medicine' | 'home_care' | 'update'

export interface CareNotification {
  id: string
  at: string
  category: NotificationCategory
  title: string
  message: string
  read: boolean
}

export interface TimelineEvent {
  id: string
  at: string
  title: string
  description: string | null
  kind: TimelineKind
  taskType: TaskType | null
}

export type EscalationCategory = 'follow_up_appointment' | 'medication'

export interface Escalation {
  id: string
  category: EscalationCategory
  taskId: string
  taskName: string
  appointmentId: string | null
  medicineId: string | null
  reason: string
  status: 'escalated' | 'in_review' | 'resolved'
  previousActions: string[]
  notificationHistory: { at: string; label: string }[]
  takenOverAt: string | null
  resolvedAt: string | null
}

export interface Patient {
  id: string
  name: string
  age: number | null
  gender: string | null
  phone: string | null
  email: string | null
  address: string | null
  diagnosis: string | null
  dischargeDate: string | null
  hospital: string | null
  coordinatorId: string
  tasks: CareTask[]
  appointments: Appointment[]
  medicines: Medicine[]
  homeCare: HomeCare | null
  notifications: CareNotification[]
  timeline: TimelineEvent[]
  escalations: Escalation[]
}

export interface CareData {
  coordinators: Coordinator[]
  patients: Patient[]
}

export type Session =
  | { role: 'patient'; name: string; patientId: string }
  | { role: 'coordinator'; name: string; coordinatorId: string }
