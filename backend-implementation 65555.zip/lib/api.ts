import { mockCareData } from './mock-data'
import type { CareData } from './types'

export async function fetchCareData(): Promise<CareData> {
  await new Promise((resolve) => setTimeout(resolve, 500))
  return structuredClone(mockCareData)
}
