from pydantic import BaseModel, Field, field_validator

from schemas.common import ORMModel, Role, UTCDateTime


class UserRegister(BaseModel):
    username: str = Field(min_length=3, max_length=255)
    password: str = Field(min_length=6, max_length=128)
    role: Role

    @field_validator("username")
    @classmethod
    def normalize_username(cls, value: str) -> str:
        return value.strip().lower()


class UserLogin(BaseModel):
    username: str = Field(min_length=1, max_length=255)
    password: str = Field(min_length=1, max_length=128)

    @field_validator("username")
    @classmethod
    def normalize_username(cls, value: str) -> str:
        return value.strip().lower()


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserResponse(ORMModel):
    id: int
    username: str
    role: Role
    created_at: UTCDateTime


class CurrentUserResponse(UserResponse):
    name: str | None = None
    patient_id: int | None = None
    coordinator_id: int | None = None
