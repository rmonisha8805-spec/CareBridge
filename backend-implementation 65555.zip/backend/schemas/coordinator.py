from pydantic import BaseModel, EmailStr, Field

from schemas.common import ORMModel


class CoordinatorBase(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    phone: str | None = Field(default=None, max_length=50)
    email: EmailStr | None = None


class CoordinatorCreate(CoordinatorBase):
    user_id: int | None = None


class CoordinatorUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=255)
    phone: str | None = Field(default=None, max_length=50)
    email: EmailStr | None = None
    user_id: int | None = None


class CoordinatorResponse(ORMModel):
    id: int
    name: str
    phone: str | None
    email: str | None
    user_id: int | None
