from datetime import datetime, timezone
from typing import Annotated, Literal

from pydantic import AfterValidator, BaseModel, ConfigDict, PlainSerializer


def _to_naive_utc(value: datetime) -> datetime:
    # Aware datetimes are converted to UTC; naive input is assumed to already be UTC.
    if value.tzinfo is not None:
        return value.astimezone(timezone.utc).replace(tzinfo=None)
    return value


def _serialize_utc(value: datetime) -> str:
    return value.replace(tzinfo=timezone.utc).isoformat().replace("+00:00", "Z")


UTCDateTime = Annotated[
    datetime,
    AfterValidator(_to_naive_utc),
    PlainSerializer(_serialize_utc, return_type=str, when_used="json"),
]


class ORMModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)


Role = Literal["patient", "coordinator"]
TaskType = Literal["appointment", "medicine", "home_care"]
TaskStatus = Literal["pending", "in_progress", "verification_pending", "completed", "failed", "escalated"]
VerificationStatus = Literal["pending", "verified", "failed"]
AppointmentStatus = Literal["scheduled", "completed", "missed", "rescheduled", "cancelled"]
AttendanceStatus = Literal["upcoming", "attended", "not_attended"]
StockStatus = Literal["available", "out_of_stock", "restocking", "restocked"]
CollectionStatus = Literal["pending", "collected", "not_collected"]
SupplyStatus = Literal["available", "out_of_stock", "restocking", "restocked", "collected", "verified"]
NotificationCategory = Literal["appointment", "medicine", "home_care", "update"]
TimelineKind = Literal["info", "success", "failed", "escalated", "coordinator", "notification"]
EscalationCategory = Literal["follow_up_appointment", "medication"]
EscalationStatus = Literal["escalated", "in_review", "resolved"]


class EmailResult(BaseModel):
    sent: bool
    detail: str


class MessageResponse(BaseModel):
    detail: str
