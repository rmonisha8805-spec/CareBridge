from datetime import datetime
from typing import TYPE_CHECKING

from sqlalchemy import DateTime, ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from database import Base, TimestampMixin

if TYPE_CHECKING:
    from models.patient import Patient


class Medication(TimestampMixin, Base):
    __tablename__ = "medications"

    id: Mapped[int] = mapped_column(primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id", ondelete="CASCADE"), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    quantity: Mapped[str] = mapped_column(String(255), nullable=False)
    form: Mapped[str] = mapped_column(String(100), nullable=False)
    dosage: Mapped[str | None] = mapped_column(String(255))
    duration: Mapped[str] = mapped_column(String(100), nullable=False)
    # Combined display status used by the frontend (available, out_of_stock, restocking, restocked, collected, verified).
    supply: Mapped[str] = mapped_column(String(20), default="available", nullable=False)
    stock_status: Mapped[str] = mapped_column(String(20), default="available", nullable=False)
    restocked_at: Mapped[datetime | None] = mapped_column(DateTime)
    collected_at: Mapped[datetime | None] = mapped_column(DateTime)
    collection_status: Mapped[str] = mapped_column(String(20), default="pending", nullable=False)
    follow_up_date: Mapped[datetime | None] = mapped_column(DateTime)

    patient: Mapped["Patient"] = relationship(back_populates="medications")
