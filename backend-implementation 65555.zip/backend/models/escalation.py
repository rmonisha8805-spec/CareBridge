from datetime import datetime
from typing import TYPE_CHECKING

from sqlalchemy import JSON, DateTime, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from database import Base, TimestampMixin

if TYPE_CHECKING:
    from models.patient import Patient


class Escalation(TimestampMixin, Base):
    __tablename__ = "escalations"

    id: Mapped[int] = mapped_column(primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id", ondelete="CASCADE"), index=True, nullable=False)
    category: Mapped[str] = mapped_column(String(30), nullable=False)
    task_id: Mapped[int | None] = mapped_column(ForeignKey("care_tasks.id", ondelete="SET NULL"))
    task_name: Mapped[str] = mapped_column(String(255), nullable=False)
    appointment_id: Mapped[int | None] = mapped_column(ForeignKey("appointments.id", ondelete="SET NULL"))
    medicine_id: Mapped[int | None] = mapped_column(ForeignKey("medications.id", ondelete="SET NULL"))
    reason: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[str] = mapped_column(String(20), default="escalated", nullable=False)
    # Audit trail shown in the coordinator resolution panel.
    previous_actions: Mapped[list[str]] = mapped_column(JSON, default=list, nullable=False)
    notification_history: Mapped[list[dict]] = mapped_column(JSON, default=list, nullable=False)
    taken_over_at: Mapped[datetime | None] = mapped_column(DateTime)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime)

    patient: Mapped["Patient"] = relationship(back_populates="escalations")
