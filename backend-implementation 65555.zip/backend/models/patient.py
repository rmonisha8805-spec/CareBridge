from datetime import datetime
from typing import TYPE_CHECKING

from sqlalchemy import DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from database import Base, TimestampMixin

if TYPE_CHECKING:
    from models.appointment import Appointment
    from models.care_task import CareTask
    from models.coordinator import Coordinator
    from models.escalation import Escalation
    from models.home_care import HomeCare
    from models.medication import Medication
    from models.notification import Notification
    from models.timeline import TimelineEvent

CHILD_CASCADE = "all, delete-orphan"


class Patient(TimestampMixin, Base):
    __tablename__ = "patients"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    age: Mapped[int | None] = mapped_column(Integer)
    gender: Mapped[str | None] = mapped_column(String(50))
    phone: Mapped[str | None] = mapped_column(String(50))
    email: Mapped[str | None] = mapped_column(String(255))
    address: Mapped[str | None] = mapped_column(Text)
    diagnosis: Mapped[str | None] = mapped_column(Text)
    discharge_date: Mapped[datetime | None] = mapped_column(DateTime)
    hospital: Mapped[str | None] = mapped_column(String(255))
    coordinator_id: Mapped[int | None] = mapped_column(ForeignKey("coordinators.id", ondelete="SET NULL"), index=True)
    # Links a patient login account to this care record.
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), unique=True)

    coordinator: Mapped["Coordinator | None"] = relationship(back_populates="patients")
    appointments: Mapped[list["Appointment"]] = relationship(back_populates="patient", cascade=CHILD_CASCADE)
    medications: Mapped[list["Medication"]] = relationship(back_populates="patient", cascade=CHILD_CASCADE)
    care_tasks: Mapped[list["CareTask"]] = relationship(back_populates="patient", cascade=CHILD_CASCADE)
    home_care: Mapped[list["HomeCare"]] = relationship(back_populates="patient", cascade=CHILD_CASCADE)
    notifications: Mapped[list["Notification"]] = relationship(back_populates="patient", cascade=CHILD_CASCADE)
    timeline_events: Mapped[list["TimelineEvent"]] = relationship(back_populates="patient", cascade=CHILD_CASCADE)
    escalations: Mapped[list["Escalation"]] = relationship(back_populates="patient", cascade=CHILD_CASCADE)
