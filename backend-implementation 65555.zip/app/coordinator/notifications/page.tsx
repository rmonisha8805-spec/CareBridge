'use client'

import { CareTimeline } from '@/components/care/care-timeline'
import { PageHeader } from '@/components/care/page-header'
import { ProtectedShell } from '@/components/care/protected-shell'

export default function CoordinatorNotificationsPage() {
  return (
    <ProtectedShell role="coordinator">
      {({ data }) => {
        const events = data.patients.flatMap((p) => p.timeline.map((e) => ({ ...e, title: `${p.name}: ${e.title}` })))
        return (
          <>
            <PageHeader title="Notifications" description="Activity across all your patients, newest first." />
            <CareTimeline events={events} description="Failures, escalations and coordinator actions across all patients." />
          </>
        )
      }}
    </ProtectedShell>
  )
}
