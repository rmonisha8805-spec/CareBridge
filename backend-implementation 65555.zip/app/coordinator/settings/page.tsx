import { PageHeader } from '@/components/care/page-header'
import { SettingsPanel } from '@/components/care/settings-panel'

export default function CoordinatorSettingsPage() {
  return (
    <>
      <PageHeader title="Settings" description="Control which alerts reach you." />
      <SettingsPanel
        preferences={[
          { id: 'escalations', label: 'New escalations', description: 'Alert me as soon as a task is escalated.', defaultOn: true },
          { id: 'failed', label: 'Failed tasks', description: 'Notify me when an automated retry fails.', defaultOn: true },
          { id: 'digest', label: 'Daily digest', description: 'A morning summary of all patients.', defaultOn: false },
        ]}
      />
    </>
  )
}
