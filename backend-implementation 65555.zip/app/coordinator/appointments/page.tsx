'use client'

import { AppointmentItem, sortAppointments } from '@/components/care/appointment-list'
import { PageHeader } from '@/components/care/page-header'
import { ProtectedShell } from '@/components/care/protected-shell'
import { EmptyState } from '@/components/care/states'

export default function CoordinatorAppointmentsPage() {
  return (
    <ProtectedShell role="coordinator">
      {({ data }) => {
        const all = data.patients.flatMap((p) => p.appointments.map((a) => ({ ...a, patientName: p.name })))
        const sorted = sortAppointments(all) as typeof all
        const missedFirst = [...sorted].sort((a, b) => Number(b.status === 'missed') - Number(a.status === 'missed'))
        return (
          <>
            <PageHeader title="Appointments" description="All patient appointments, with missed ones first." />
            {missedFirst.length === 0 ? (
              <EmptyState message="No appointments." />
            ) : (
              <ul className="flex flex-col gap-3">
                {missedFirst.map((a) => (
                  <AppointmentItem key={a.id} appointment={a} patientName={a.patientName} viewer="coordinator" />
                ))}
              </ul>
            )}
          </>
        )
      }}
    </ProtectedShell>
  )
}
