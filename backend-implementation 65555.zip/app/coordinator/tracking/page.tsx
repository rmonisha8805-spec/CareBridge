'use client'

import { CareTracker } from '@/components/care/care-tracker'
import { PageHeader } from '@/components/care/page-header'
import { ProtectedShell } from '@/components/care/protected-shell'

export default function CoordinatorTrackingPage() {
  return (
    <ProtectedShell role="coordinator">
      {({ data }) => (
        <div className="flex flex-col gap-6">
          <PageHeader title="Care Tracking" description="Journey progress for every patient." />
          {data.patients.map((p) => (
            <CareTracker key={p.id} tasks={p.tasks} title={p.name} />
          ))}
        </div>
      )}
    </ProtectedShell>
  )
}
