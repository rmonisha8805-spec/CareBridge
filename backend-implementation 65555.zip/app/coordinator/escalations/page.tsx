'use client'

import { EscalationCard } from '@/components/care/escalation-card'
import { PageHeader } from '@/components/care/page-header'
import { ProtectedShell } from '@/components/care/protected-shell'
import { Section } from '@/components/care/section'
import { EmptyState } from '@/components/care/states'
import { CheckCircle2, Siren } from 'lucide-react'

export default function CoordinatorEscalationsPage() {
  return (
    <ProtectedShell role="coordinator">
      {({ session, data }) => {
        const all = data.patients.flatMap((p) => p.escalations.map((e) => ({ patient: p, escalation: e })))
        const open = all.filter((x) => x.escalation.status !== 'resolved')
        const resolved = all.filter((x) => x.escalation.status === 'resolved')
        return (
          <div className="flex flex-col gap-6">
            <PageHeader title="Escalations" description="Tasks that automation could not complete. Press Act to take over." />
            <Section id="open-escalations" title={`Open (${open.length})`} icon={Siren}>
              {open.length === 0 ? (
                <EmptyState message="No open escalations. Everything is on track." />
              ) : (
                <div className="grid gap-4 lg:grid-cols-2">
                  {open.map(({ patient, escalation }) => (
                    <EscalationCard key={escalation.id} patient={patient} escalation={escalation} coordinatorName={session.name} showPatientLink />
                  ))}
                </div>
              )}
            </Section>
            {resolved.length > 0 && (
              <Section id="resolved-escalations" title={`Resolved (${resolved.length})`} icon={CheckCircle2}>
                <div className="grid gap-4 lg:grid-cols-2">
                  {resolved.map(({ patient, escalation }) => (
                    <EscalationCard key={escalation.id} patient={patient} escalation={escalation} coordinatorName={session.name} showPatientLink />
                  ))}
                </div>
              </Section>
            )}
          </div>
        )
      }}
    </ProtectedShell>
  )
}
