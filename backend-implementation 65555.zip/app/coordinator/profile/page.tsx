'use client'

import { UserRound } from 'lucide-react'
import { DetailList } from '@/components/care/detail-list'
import { PageHeader } from '@/components/care/page-header'
import { ProtectedShell } from '@/components/care/protected-shell'
import { Section } from '@/components/care/section'

export default function CoordinatorProfilePage() {
  return (
    <ProtectedShell role="coordinator">
      {({ session, data }) => {
        const me = session.role === 'coordinator' ? data.coordinators.find((c) => c.id === session.coordinatorId) : undefined
        const assigned = data.patients.filter((p) => p.coordinatorId === me?.id).length
        return (
          <>
            <PageHeader title="Profile" description="Your coordinator account details." />
            <Section id="profile" title={me?.name ?? session.name} icon={UserRound}>
              <DetailList
                items={[
                  { label: 'Role', value: 'Care Coordinator' },
                  { label: 'Phone', value: me?.phone },
                  { label: 'Email', value: me?.email },
                  { label: 'Assigned patients', value: assigned },
                ]}
              />
            </Section>
          </>
        )
      }}
    </ProtectedShell>
  )
}
