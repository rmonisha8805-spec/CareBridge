import { RoleLayout } from '@/components/care/role-layout'

export default function CoordinatorLayout({ children }: { children: React.ReactNode }) {
  return <RoleLayout role="coordinator">{children}</RoleLayout>
}
