'use client'

import { MedicineList } from '@/components/care/medicine-list'
import { PageHeader } from '@/components/care/page-header'
import { ProtectedShell } from '@/components/care/protected-shell'

export default function CoordinatorMedicationsPage() {
  return (
    <ProtectedShell role="coordinator">
      {({ data }) => (
        <div className="flex flex-col gap-6">
          <PageHeader title="Medications" description="Supply status of every prescribed medicine." />
          {data.patients.map((p) => (
            <div key={p.id}>
              <h2 className="mb-3 text-lg font-semibold">{p.name}</h2>
              <MedicineList medicines={p.medicines} columns={2} />
            </div>
          ))}
        </div>
      )}
    </ProtectedShell>
  )
}
