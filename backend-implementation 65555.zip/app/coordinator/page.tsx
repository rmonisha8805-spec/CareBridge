'use client'

import { CoordinatorDashboard } from '@/components/care/coordinator-dashboard'
import { ProtectedShell } from '@/components/care/protected-shell'

export default function CoordinatorPage() {
  return <ProtectedShell role="coordinator">{({ session, data }) => <CoordinatorDashboard data={data} session={session} />}</ProtectedShell>
}
