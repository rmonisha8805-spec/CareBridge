'use client'

import { use } from 'react'
import Link from 'next/link'
import { ArrowLeft, Siren } from 'lucide-react'
import { CareTasks } from '@/components/care/care-tasks'
import { CareTimeline } from '@/components/care/care-timeline'
import { CareTracker } from '@/components/care/care-tracker'
import { CoordinatorCard } from '@/components/care/coordinator-card'
import { EscalationCard } from '@/components/care/escalation-card'
import { HomeCareCard } from '@/components/care/home-care-card'
import { MedicineList } from '@/components/care/medicine-list'
import { PatientHeader } from '@/components/care/patient-header'
import { ProtectedShell } from '@/components/care/protected-shell'
import { Section } from '@/components/care/section'
import { EmptyState } from '@/components/care/states'

export default function CoordinatorPatientPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)

  return (
    <ProtectedShell role="coordinator">
      {({ session, data }) => {
        const patient = data.patients.find((p) => p.id === id)
        return (
          <div className="flex flex-col gap-6">
            <Link href="/coordinator/patients" className="inline-flex w-fit items-center gap-2 text-sm font-medium text-primary hover:underline">
              <ArrowLeft className="size-4" aria-hidden="true" />
              Back to patients
            </Link>
            {!patient ? (
              <EmptyState message="Patient not found." />
            ) : (
              <>
                <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
                  <PatientHeader patient={patient} />
                  <CoordinatorCard coordinator={data.coordinators.find((c) => c.id === patient.coordinatorId)} />
                </div>

                {patient.escalations.length > 0 && (
                  <Section id="escalations" title="Escalations" description="Review what went wrong and take action." icon={Siren}>
                    <div className="grid gap-4 lg:grid-cols-2">
                      {patient.escalations.map((e) => (
                        <EscalationCard
                          key={e.id}
                          patient={patient}
                          escalation={e}
                          coordinatorName={session.name}
                        />
                      ))}
                    </div>
                  </Section>
                )}

                <CareTasks tasks={patient.tasks} />
                <CareTracker tasks={patient.tasks} />
                <div className="grid items-start gap-6 lg:grid-cols-2">
                  <MedicineList medicines={patient.medicines} />
                  <HomeCareCard
                    patientId={patient.id}
                    homeCare={patient.homeCare}
                    task={patient.tasks.find((t) => t.type === 'home_care')}
                    viewer="coordinator"
                  />
                </div>
                <CareTimeline events={patient.timeline} description="Full chronological history, including retries, escalations and coordinator actions." />
              </>
            )}
          </div>
        )
      }}
    </ProtectedShell>
  )
}
