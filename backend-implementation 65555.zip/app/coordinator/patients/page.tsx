'use client'

import Link from 'next/link'
import { ChevronRight } from 'lucide-react'
import { PageHeader } from '@/components/care/page-header'
import { ProtectedShell } from '@/components/care/protected-shell'
import { StatusBadge } from '@/components/care/status-badge'
import { formatDate, initials } from '@/lib/format'

export default function CoordinatorPatientsPage() {
  return (
    <ProtectedShell role="coordinator">
      {({ data }) => (
        <>
          <PageHeader title="Patients" description={`${data.patients.length} discharged patients under care.`} />
          <ul className="flex flex-col gap-3">
            {data.patients.map((p) => {
              const open = p.escalations.filter((e) => e.status !== 'resolved').length
              return (
                <li key={p.id}>
                  <Link
                    href={`/coordinator/patients/${p.id}`}
                    className="flex flex-wrap items-center gap-4 rounded-xl border bg-card p-4 transition-colors hover:border-primary/40 hover:bg-muted/40"
                  >
                    <span aria-hidden="true" className="flex size-11 items-center justify-center rounded-full bg-accent font-semibold text-accent-foreground">
                      {initials(p.name)}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="text-lg font-semibold">{p.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {p.diagnosis ?? 'No diagnosis recorded'}
                        {p.dischargeDate && ` · Discharged ${formatDate(p.dischargeDate)}`}
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {p.tasks.map((t) => (
                        <StatusBadge key={t.id} status={t.status} />
                      ))}
                    </div>
                    {open > 0 && (
                      <span className="rounded-full bg-escalated px-2.5 py-1 text-xs font-semibold text-primary-foreground">
                        {open} escalation{open > 1 && 's'}
                      </span>
                    )}
                    <ChevronRight className="size-5 text-muted-foreground" aria-hidden="true" />
                  </Link>
                </li>
              )
            })}
          </ul>
        </>
      )}
    </ProtectedShell>
  )
}
