import { CheckCircle2, HeartPulse } from 'lucide-react'
import { LoginForm } from '@/components/care/login-form'

const highlights = [
  'Track appointments, medicines and home visits in one place',
  'See exactly where your recovery stands, step by step',
  'Reach your care coordinator whenever you need help',
]

export default function LoginPage() {
  return (
    <main className="grid min-h-screen lg:grid-cols-2">
      <section className="hidden flex-col justify-between bg-primary p-12 text-primary-foreground lg:flex">
        <div className="flex items-center gap-2 text-lg font-semibold">
          <span className="flex size-10 items-center justify-center rounded-lg bg-primary-foreground/15">
            <HeartPulse className="size-5" aria-hidden="true" />
          </span>
          CareBridge
        </div>
        <div className="max-w-md">
          <h2 className="text-4xl font-semibold leading-tight text-balance">Care that continues after you leave the hospital.</h2>
          <ul className="mt-8 flex flex-col gap-4">
            {highlights.map((h) => (
              <li key={h} className="flex items-start gap-3 text-base text-primary-foreground/90">
                <CheckCircle2 className="mt-0.5 size-5 shrink-0" aria-hidden="true" />
                {h}
              </li>
            ))}
          </ul>
        </div>
        <p className="text-sm text-primary-foreground/70">Post-discharge care coordination platform</p>
      </section>

      <section className="flex items-center justify-center px-4 py-12 md:px-8">
        <div className="w-full max-w-md">
          <div className="mb-8 flex items-center gap-2 text-lg font-semibold lg:hidden">
            <span className="flex size-10 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <HeartPulse className="size-5" aria-hidden="true" />
            </span>
            CareBridge
          </div>
          <h1 className="text-3xl font-semibold">Sign in</h1>
          <p className="mb-8 mt-2 text-base text-muted-foreground">Access your post-discharge care plan or coordinator dashboard.</p>
          <div className="rounded-2xl border bg-card p-6 shadow-sm">
            <LoginForm />
          </div>
        </div>
      </section>
    </main>
  )
}
