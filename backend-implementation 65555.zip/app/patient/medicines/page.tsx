'use client'

import { MedicineList } from '@/components/care/medicine-list'
import { PageHeader } from '@/components/care/page-header'
import { PatientShell } from '@/components/care/protected-shell'

export default function PatientMedicinesPage() {
  return (
    <PatientShell>
      {({ patient }) => (
        <>
          <PageHeader title="Medicines" description="Your prescriptions and where each one is in the supply process." />
          <MedicineList medicines={patient.medicines} columns={2} />
        </>
      )}
    </PatientShell>
  )
}
