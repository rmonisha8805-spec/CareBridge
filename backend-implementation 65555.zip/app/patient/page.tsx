'use client'

import Link from 'next/link'
import { ArrowRight, Bell, BellRing } from 'lucide-react'
import { CareTasks } from '@/components/care/care-tasks'
import { CareTracker } from '@/components/care/care-tracker'
import { CoordinatorCard } from '@/components/care/coordinator-card'
import { NotificationList } from '@/components/care/notification-list'
import { PatientHeader } from '@/components/care/patient-header'
import { PatientShell } from '@/components/care/protected-shell'
import { Section } from '@/components/care/section'

export default function PatientDashboardPage() {
  return (
    <PatientShell>
      {({ patient, data }) => {
        const coordinator = data.coordinators.find((c) => c.id === patient.coordinatorId)
        const awaitingConfirmation = patient.homeCare?.arrivedAt && !patient.homeCare.confirmedAt

        return (
          <div className="flex flex-col gap-6">
            <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
              <PatientHeader patient={patient} greeting />
              <CoordinatorCard coordinator={coordinator} />
            </div>

            {awaitingConfirmation && (
              <Link
                href="/patient/home-care"
                className="flex items-center gap-3 rounded-xl border border-warning/30 bg-warning-soft p-4 text-warning transition-colors hover:bg-warning-soft/70"
              >
                <BellRing className="size-5 shrink-0" aria-hidden="true" />
                <span className="flex-1 text-base font-medium">
                  Action needed: {patient.homeCare?.staffName} has arrived. Please confirm your home visit.
                </span>
                <ArrowRight className="size-5" aria-hidden="true" />
              </Link>
            )}

            <CareTasks tasks={patient.tasks} />
            <CareTracker tasks={patient.tasks} />

            <Section
              id="recent-notifications"
              title="Recent Notifications"
              icon={Bell}
              action={
                <Link href="/patient/notifications" className="text-sm font-medium text-primary hover:underline">
                  View all
                </Link>
              }
            >
              <NotificationList patientId={patient.id} notifications={patient.notifications} limit={3} />
            </Section>
          </div>
        )
      }}
    </PatientShell>
  )
}
