import { PageHeader } from '@/components/care/page-header'
import { SettingsPanel } from '@/components/care/settings-panel'

export default function PatientSettingsPage() {
  return (
    <>
      <PageHeader title="Settings" description="Choose how you want to hear about your care." />
      <SettingsPanel
        preferences={[
          { id: 'appointments', label: 'Appointment reminders', description: 'A reminder the day before each appointment.', defaultOn: true },
          { id: 'medicines', label: 'Medicine updates', description: 'When a medicine is restocked or ready to collect.', defaultOn: true },
          { id: 'homecare', label: 'Home visit alerts', description: 'When your nurse arrives and needs confirmation.', defaultOn: true },
          { id: 'sms', label: 'SMS messages', description: 'Also send important updates to your phone.', defaultOn: false },
        ]}
      />
    </>
  )
}
