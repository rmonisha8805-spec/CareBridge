'use client'

import { UserRound } from 'lucide-react'
import { CoordinatorCard } from '@/components/care/coordinator-card'
import { DetailList } from '@/components/care/detail-list'
import { PageHeader } from '@/components/care/page-header'
import { PatientShell } from '@/components/care/protected-shell'
import { Section } from '@/components/care/section'
import { formatDate } from '@/lib/format'

export default function PatientProfilePage() {
  return (
    <PatientShell>
      {({ patient, data }) => (
        <>
          <PageHeader title="My Profile" description="Your personal and discharge details." />
          <div className="grid items-start gap-6 lg:grid-cols-[1fr_320px]">
            <Section id="profile" title={patient.name} icon={UserRound}>
              <DetailList
                items={[
                  { label: 'Age', value: patient.age },
                  { label: 'Gender', value: patient.gender },
                  { label: 'Phone', value: patient.phone },
                  { label: 'Email', value: patient.email },
                  { label: 'Address', value: patient.address },
                  { label: 'Diagnosis', value: patient.diagnosis },
                  { label: 'Hospital', value: patient.hospital },
                  { label: 'Discharge date', value: formatDate(patient.dischargeDate) },
                ]}
              />
            </Section>
            <CoordinatorCard coordinator={data.coordinators.find((c) => c.id === patient.coordinatorId)} />
          </div>
        </>
      )}
    </PatientShell>
  )
}
