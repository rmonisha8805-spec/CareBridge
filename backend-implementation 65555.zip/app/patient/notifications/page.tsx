'use client'

import { CheckCheck } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { NotificationList } from '@/components/care/notification-list'
import { PageHeader } from '@/components/care/page-header'
import { PatientShell } from '@/components/care/protected-shell'
import { markAllNotificationsRead } from '@/lib/care-store'

export default function PatientNotificationsPage() {
  return (
    <PatientShell>
      {({ patient }) => {
        const unread = patient.notifications.filter((n) => !n.read).length
        return (
          <>
            <PageHeader
              title="Notifications"
              description={unread > 0 ? `You have ${unread} unread ${unread === 1 ? 'notification' : 'notifications'}.` : 'You are all caught up.'}
              action={
                unread > 0 && (
                  <Button variant="outline" onClick={() => markAllNotificationsRead(patient.id)} className="h-11 text-base">
                    <CheckCheck aria-hidden="true" />
                    Mark all as read
                  </Button>
                )
              }
            />
            <NotificationList patientId={patient.id} notifications={patient.notifications} />
          </>
        )
      }}
    </PatientShell>
  )
}
