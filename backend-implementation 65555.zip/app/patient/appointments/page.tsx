'use client'

import { AppointmentList } from '@/components/care/appointment-list'
import { PageHeader } from '@/components/care/page-header'
import { PatientShell } from '@/components/care/protected-shell'

export default function PatientAppointmentsPage() {
  return (
    <PatientShell>
      {({ patient }) => (
        <>
          <PageHeader title="Appointments" description="Your upcoming and past hospital appointments." />
          <AppointmentList appointments={patient.appointments} />
        </>
      )}
    </PatientShell>
  )
}
