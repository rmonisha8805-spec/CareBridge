'use client'

import { CareTimeline } from '@/components/care/care-timeline'
import { CareTracker } from '@/components/care/care-tracker'
import { PageHeader } from '@/components/care/page-header'
import { PatientShell } from '@/components/care/protected-shell'

export default function PatientTrackerPage() {
  return (
    <PatientShell>
      {({ patient }) => (
        <div className="flex flex-col gap-6">
          <PageHeader title="Care Tracker" description="A step-by-step map of your recovery journey. Completed steps turn green." />
          <CareTracker tasks={patient.tasks} variant="flow" title="Care Journey" />
          <CareTimeline events={patient.timeline} />
        </div>
      )}
    </PatientShell>
  )
}
