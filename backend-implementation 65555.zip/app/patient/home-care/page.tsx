'use client'

import { HomeCareCard } from '@/components/care/home-care-card'
import { PageHeader } from '@/components/care/page-header'
import { PatientShell } from '@/components/care/protected-shell'

export default function PatientHomeCarePage() {
  return (
    <PatientShell>
      {({ patient }) => (
        <>
          <PageHeader title="Home Care" description="Track your home visit. Confirm once the nurse or field worker has visited you." />
          <HomeCareCard
            patientId={patient.id}
            homeCare={patient.homeCare}
            task={patient.tasks.find((t) => t.type === 'home_care')}
            viewer="patient"
          />
        </>
      )}
    </PatientShell>
  )
}
