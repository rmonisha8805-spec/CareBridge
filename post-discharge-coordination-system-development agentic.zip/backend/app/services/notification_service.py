import logging
import uuid
from typing import Protocol

from app.models.enums import NotificationChannel, NotificationStatus, RecipientType, StaffRole
from app.models.notification import NotificationRecord
from app.services.clock import Clock

logger = logging.getLogger(__name__)


class NotificationDispatcher(Protocol):
    async def dispatch(self, notification: NotificationRecord) -> tuple[NotificationStatus, str | None]: ...


class LoggingNotificationDispatcher:
    """Development dispatcher: logs metadata only and fails when no channel is on file."""

    async def dispatch(self, notification: NotificationRecord) -> tuple[NotificationStatus, str | None]:
        if notification.channel is None:
            return NotificationStatus.FAILED, "No notification channel on file for recipient"
        logger.info(
            "Notification dispatched id=%s task=%s recipient=%s role=%s channel=%s type=%s",
            notification.notification_id,
            notification.task_id,
            notification.recipient_type,
            notification.recipient_role,
            notification.channel,
            notification.message_type,
        )
        return NotificationStatus.SENT, None


def build_dispatcher(name: str) -> NotificationDispatcher:
    if name == "log":
        return LoggingNotificationDispatcher()
    raise ValueError(f"Unsupported notification dispatcher: {name!r}")


class NotificationService:
    def __init__(self, dispatcher: NotificationDispatcher, clock: Clock, staff_channel: NotificationChannel) -> None:
        self._dispatcher = dispatcher
        self._clock = clock
        self._staff_channel = staff_channel

    async def notify_patient(
        self,
        *,
        task_id: str,
        patient_id: str,
        channel: NotificationChannel | None,
        message_type: str,
        message: str,
    ) -> NotificationRecord:
        return await self._send(
            task_id=task_id,
            patient_id=patient_id,
            recipient_type=RecipientType.PATIENT,
            recipient_role=None,
            channel=channel,
            message_type=message_type,
            message=message,
        )

    async def notify_staff(
        self,
        *,
        task_id: str,
        patient_id: str,
        role: StaffRole,
        message_type: str,
        message: str,
    ) -> NotificationRecord:
        return await self._send(
            task_id=task_id,
            patient_id=patient_id,
            recipient_type=RecipientType.STAFF,
            recipient_role=role,
            channel=self._staff_channel,
            message_type=message_type,
            message=message,
        )

    async def resend(self, notification: NotificationRecord) -> NotificationRecord:
        return await self._send(
            task_id=notification.task_id,
            patient_id=notification.patient_id,
            recipient_type=notification.recipient_type,
            recipient_role=notification.recipient_role,
            channel=notification.channel,
            message_type=notification.message_type,
            message=notification.message,
        )

    async def _send(
        self,
        *,
        task_id: str,
        patient_id: str,
        recipient_type: RecipientType,
        recipient_role: StaffRole | None,
        channel: NotificationChannel | None,
        message_type: str,
        message: str,
    ) -> NotificationRecord:
        draft = NotificationRecord(
            notification_id=str(uuid.uuid4()),
            task_id=task_id,
            patient_id=patient_id,
            recipient_type=recipient_type,
            recipient_role=recipient_role,
            channel=channel,
            message_type=message_type,
            message=message,
            status=NotificationStatus.FAILED,
            created_at=self._clock(),
        )
        try:
            status, error = await self._dispatcher.dispatch(draft)
        except Exception as exc:  # a broken channel must not crash the care workflow
            logger.exception("Notification dispatch raised for task=%s", task_id)
            status, error = NotificationStatus.FAILED, f"Dispatcher error: {exc}"
        return draft.model_copy(update={"status": status, "error": error})
