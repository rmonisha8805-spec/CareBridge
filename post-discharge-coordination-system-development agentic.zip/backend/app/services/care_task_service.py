import asyncio
import logging
import uuid
from collections import defaultdict
from typing import Any

from langgraph.errors import GraphRecursionError
from langgraph.graph.state import CompiledStateGraph

from app.database.database import Database
from app.database.repositories import CareRecordRepository, EscalationRepository, TaskRepository
from app.graph.context import WorkflowContext, build_run_config
from app.graph.state import CareState, audit
from app.models.appointment import AppointmentRecord
from app.models.enums import (
    EventType,
    MedicationStatus,
    NotificationChannel,
    TaskStatus,
    TaskType,
    VerificationTarget,
)
from app.models.events import WorkflowEvent
from app.models.medication import MedicationRecord

logger = logging.getLogger(__name__)

EVENTS_BY_TASK_TYPE: dict[TaskType, frozenset[EventType]] = {
    TaskType.APPOINTMENT: frozenset({EventType.APPOINTMENT_STATUS_UPDATE, EventType.APPOINTMENT_RESCHEDULED}),
    TaskType.MEDICATION: frozenset({EventType.MEDICATION_AVAILABILITY_UPDATE, EventType.MEDICATION_COLLECTION_UPDATE}),
}
SHARED_EVENTS = frozenset(
    {
        EventType.MONITOR_CHECK,
        EventType.VERIFICATION_EVIDENCE,
        EventType.ESCALATION_REQUESTED,
        EventType.ESCALATION_ACKNOWLEDGED,
        EventType.ESCALATION_RESOLUTION_REQUESTED,
    }
)
EVIDENCE_TARGETS: dict[TaskType, frozenset[VerificationTarget]] = {
    TaskType.APPOINTMENT: frozenset(
        {
            VerificationTarget.APPOINTMENT_ATTENDANCE,
            VerificationTarget.RESCHEDULED_APPOINTMENT_ATTENDANCE,
        }
    ),
    TaskType.MEDICATION: frozenset(
        {VerificationTarget.MEDICATION_AVAILABILITY, VerificationTarget.MEDICATION_COLLECTION}
    ),
}


class TaskNotFoundError(Exception):
    pass


class InvalidEventError(Exception):
    pass


class WorkflowRejectedError(Exception):
    def __init__(self, message: str, state: CareState) -> None:
        super().__init__(message)
        self.state = state


class CareTaskService:
    def __init__(
        self,
        db: Database,
        workflow: CompiledStateGraph,
        context: WorkflowContext,
    ) -> None:
        self._db = db
        self._workflow = workflow
        self._context = context
        self._tasks = TaskRepository(db)
        self._escalations = EscalationRepository(db)
        self._records = CareRecordRepository(db)
        self._locks: defaultdict[str, asyncio.Lock] = defaultdict(asyncio.Lock)

    @property
    def clock(self):
        return self._context.clock

    @property
    def tasks(self) -> TaskRepository:
        return self._tasks

    @property
    def escalations(self) -> EscalationRepository:
        return self._escalations

    @property
    def records(self) -> CareRecordRepository:
        return self._records

    async def create_appointment_task(
        self,
        *,
        patient_id: str,
        patient_channel: NotificationChannel | None,
        appointment: dict[str, Any],
    ) -> CareState:
        now = self._context.clock()
        record = AppointmentRecord(
            appointment_id=appointment.get("appointment_id") or str(uuid.uuid4()),
            **{k: v for k, v in appointment.items() if k != "appointment_id"},
            updated_at=now,
        )
        state = self._new_state(TaskType.APPOINTMENT, patient_id, patient_channel, appointment=record)
        return await self._run(state, self._event(EventType.START, {}, actor=None))

    async def create_medication_task(
        self,
        *,
        patient_id: str,
        patient_channel: NotificationChannel | None,
        medication: dict[str, Any],
    ) -> CareState:
        now = self._context.clock()
        availability = medication.get("availability", MedicationStatus.UNKNOWN)
        record = MedicationRecord(
            medication_id=medication.get("medication_id") or str(uuid.uuid4()),
            **{k: v for k, v in medication.items() if k != "medication_id"},
            out_of_stock_since=now if availability == MedicationStatus.OUT_OF_STOCK else None,
            updated_at=now,
        )
        state = self._new_state(TaskType.MEDICATION, patient_id, patient_channel, medication=record)
        return await self._run(state, self._event(EventType.START, {}, actor=None))

    async def submit_event(
        self, task_id: str, event_type: EventType, payload: dict[str, Any], actor: str | None = None
    ) -> CareState:
        async with self._locks[task_id]:
            state = await self._tasks.get(task_id)
            if state is None:
                raise TaskNotFoundError(task_id)
            self._validate_event(state, event_type, payload)
            return await self._run(state, self._event(event_type, payload, actor), locked=True)

    async def get_task(self, task_id: str) -> CareState:
        state = await self._tasks.get(task_id)
        if state is None:
            raise TaskNotFoundError(task_id)
        return state

    def _new_state(
        self,
        task_type: TaskType,
        patient_id: str,
        patient_channel: NotificationChannel | None,
        **records: Any,
    ) -> CareState:
        now = self._context.clock()
        return CareState(
            task_id=str(uuid.uuid4()),
            patient_id=patient_id,
            task_type=task_type,
            patient_channel=patient_channel,
            created_at=now,
            updated_at=now,
            **records,
        )

    def _event(self, event_type: EventType, payload: dict[str, Any], actor: str | None) -> WorkflowEvent:
        return WorkflowEvent(type=event_type, payload=payload, occurred_at=self._context.clock(), actor=actor)

    def _validate_event(self, state: CareState, event_type: EventType, payload: dict[str, Any]) -> None:
        if state.task_status == TaskStatus.COMPLETED:
            raise InvalidEventError("Task is already completed")
        if event_type not in EVENTS_BY_TASK_TYPE[state.task_type] | SHARED_EVENTS:
            raise InvalidEventError(f"{event_type} is not valid for {state.task_type} tasks")
        if event_type == EventType.VERIFICATION_EVIDENCE:
            target = VerificationTarget(payload["target"])
            if target not in EVIDENCE_TARGETS[state.task_type]:
                raise InvalidEventError(f"{target} evidence is not valid for {state.task_type} tasks")
        if event_type == EventType.ESCALATION_REQUESTED and state.has_active_escalation:
            raise InvalidEventError("Task already has an active escalation")

    async def _run(self, state: CareState, event: WorkflowEvent, locked: bool = False) -> CareState:
        if not locked:
            async with self._locks[state.task_id]:
                return await self._run(state, event, locked=True)

        prepared = state.model_copy(
            update={
                "event": event,
                "decision": None,
                "error": None,
                "task_status": TaskStatus.ESCALATED if state.has_active_escalation else TaskStatus.IN_PROGRESS,
            }
        )
        try:
            result = await self._workflow.ainvoke(prepared, config=build_run_config(self._context))
            final = CareState.model_validate(result)
        except GraphRecursionError:
            logger.error("Workflow recursion limit hit for task=%s event=%s", state.task_id, event.type)
            now = self._context.clock()
            final = prepared.model_copy(
                update={
                    "error": "Workflow exceeded its step limit; task left unchanged for staff review",
                    "audit_log": prepared.audit_log + audit("workflow", "Recursion limit reached", now),
                }
            )

        final = final.model_copy(update={"updated_at": self._context.clock()})
        await self._persist(state, final)

        if final.error:
            raise WorkflowRejectedError(final.error, final)
        return final

    async def _persist(self, before: CareState, after: CareState) -> None:
        known_ids = {n.notification_id for n in before.notifications}
        new_notifications = [n for n in after.notifications if n.notification_id not in known_ids]
        verification_changed = after.verification != before.verification

        async with self._db.transaction() as conn:
            await self._tasks.upsert(conn, after)
            if after.appointment:
                await self._records.upsert_appointment(conn, after.task_id, after.patient_id, after.appointment)
            if after.medication:
                await self._records.upsert_medication(conn, after.task_id, after.patient_id, after.medication)
            if verification_changed:
                await self._records.add_verification_records(conn, after.task_id, after.verification.records.values())
            if new_notifications:
                await self._records.add_notifications(conn, new_notifications)
            if after.escalation:
                await self._escalations.upsert(conn, after.escalation)
