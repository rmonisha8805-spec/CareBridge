import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, status
from fastapi.responses import JSONResponse

from app.api.routes import router, to_response
from app.config import Settings, get_settings
from app.database.database import Database
from app.graph.context import WorkflowContext
from app.graph.workflow import build_care_workflow
from app.models.enums import NotificationChannel
from app.services.care_task_service import (
    CareTaskService,
    InvalidEventError,
    TaskNotFoundError,
    WorkflowRejectedError,
)
from app.services.clock import Clock, utc_now
from app.services.notification_service import NotificationDispatcher, NotificationService, build_dispatcher


def create_app(
    settings: Settings | None = None,
    clock: Clock = utc_now,
    dispatcher: NotificationDispatcher | None = None,
) -> FastAPI:
    settings = settings or get_settings()
    logging.basicConfig(level=settings.log_level, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        db = Database(settings.database_url)
        await db.connect()
        notifications = NotificationService(
            dispatcher or build_dispatcher(settings.notification_dispatcher),
            clock,
            NotificationChannel(settings.staff_notification_channel),
        )
        context = WorkflowContext(settings=settings, notifications=notifications, clock=clock)
        app.state.care_service = CareTaskService(db, build_care_workflow(), context)
        try:
            yield
        finally:
            await db.close()

    app = FastAPI(title=settings.app_name, version="1.0.0", lifespan=lifespan)
    app.include_router(router)

    @app.exception_handler(TaskNotFoundError)
    async def task_not_found(_: Request, exc: TaskNotFoundError) -> JSONResponse:
        return JSONResponse(status_code=status.HTTP_404_NOT_FOUND, content={"detail": f"Task {exc} not found"})

    @app.exception_handler(InvalidEventError)
    async def invalid_event(_: Request, exc: InvalidEventError) -> JSONResponse:
        return JSONResponse(status_code=status.HTTP_422_UNPROCESSABLE_CONTENT, content={"detail": str(exc)})

    @app.exception_handler(WorkflowRejectedError)
    async def workflow_rejected(_: Request, exc: WorkflowRejectedError) -> JSONResponse:
        body = {"detail": str(exc), "task": to_response(exc.state).model_dump(mode="json")}
        return JSONResponse(status_code=status.HTTP_409_CONFLICT, content=body)

    return app


app = create_app()
