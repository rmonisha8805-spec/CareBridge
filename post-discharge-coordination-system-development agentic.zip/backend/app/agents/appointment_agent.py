"""Appointment Agent: tracks follow-up attendance, misses and rescheduling."""

import logging
from datetime import datetime
from typing import Any

from langchain_core.runnables import RunnableConfig

from app.graph.context import WorkflowContext, get_context
from app.graph.routing import APPOINTMENT_AGENT, appointment_requires_escalation
from app.graph.state import CareState, audit
from app.models.appointment import AppointmentRecord
from app.models.enums import (
    AppointmentStatus,
    EventType,
    NotificationStatus,
    TaskStatus,
    VerificationTarget,
    WorkflowDecision,
)
from app.models.events import AppointmentStatusPayload, ReschedulePayload

logger = logging.getLogger(__name__)

ATTENDANCE_TARGETS = (
    VerificationTarget.APPOINTMENT_ATTENDANCE,
    VerificationTarget.RESCHEDULED_APPOINTMENT_ATTENDANCE,
)
MISSED_MESSAGE_TYPE = "APPOINTMENT_MISSED_RESCHEDULE"
REMINDER_MESSAGE_TYPE = "APPOINTMENT_RESCHEDULE_REMINDER"


async def appointment_agent(state: CareState, config: RunnableConfig) -> dict[str, Any]:
    context = get_context(config)
    now = context.clock()
    appointment = state.appointment
    if appointment is None:
        return _reject("Task has no appointment to track", now)

    if state.decision == WorkflowDecision.RETRY:
        return await _handle_retry(state, appointment, context, now)

    event_type = state.event.type if state.event else EventType.START
    if event_type == EventType.APPOINTMENT_STATUS_UPDATE:
        return await _handle_status_update(state, appointment, context, now)
    if event_type == EventType.APPOINTMENT_RESCHEDULED:
        return _handle_reschedule(state, appointment, now)

    return {
        "decision": WorkflowDecision.VERIFY,
        "audit_log": audit(APPOINTMENT_AGENT, f"Tracking appointment {appointment.appointment_id} ({appointment.status})", now),
    }


async def _handle_status_update(
    state: CareState, appointment: AppointmentRecord, context: WorkflowContext, now: datetime
) -> dict[str, Any]:
    payload = AppointmentStatusPayload.model_validate(state.event.payload)
    if appointment.status == AppointmentStatus.COMPLETED:
        return _reject("Appointment is already completed", now)

    if payload.status == AppointmentStatus.COMPLETED:
        updated = appointment.model_copy(
            update={
                "status": AppointmentStatus.COMPLETED,
                "attended_at": payload.occurred_at or now,
                "attendance_source": payload.source,
                "reschedule_allowed": False,
                "updated_at": now,
            }
        )
        return {
            "appointment": updated,
            "evidence": _clear_attendance_evidence(state),
            "decision": WorkflowDecision.VERIFY,
            "audit_log": audit(APPOINTMENT_AGENT, f"Attendance reported by {payload.source}", now),
        }

    if appointment.status == AppointmentStatus.MISSED:
        return {
            "decision": WorkflowDecision.MONITOR,
            "audit_log": audit(APPOINTMENT_AGENT, "Duplicate missed report for the same slot ignored", now),
        }

    missed_count = appointment.missed_count + 1
    updated = appointment.model_copy(
        update={
            "status": AppointmentStatus.MISSED,
            "missed_count": missed_count,
            "last_missed_at": payload.occurred_at or now,
            "attended_at": None,
            "updated_at": now,
        }
    )
    threshold = context.settings.appointment_escalation_threshold
    if appointment_requires_escalation(missed_count, threshold):
        return {
            "appointment": updated,
            "escalation_required": True,
            "escalation_reason": f"Follow-up appointment missed {missed_count} times",
            "decision": WorkflowDecision.ESCALATE,
            "audit_log": audit(APPOINTMENT_AGENT, f"Miss #{missed_count} reached escalation threshold {threshold}", now),
        }

    notification = await context.notifications.notify_patient(
        task_id=state.task_id,
        patient_id=state.patient_id,
        channel=state.patient_channel,
        message_type=MISSED_MESSAGE_TYPE,
        message="You missed your follow-up appointment. Please contact us to reschedule.",
    )
    return {
        "appointment": updated.model_copy(update={"reschedule_allowed": True}),
        "notifications": [notification],
        "decision": WorkflowDecision.VERIFY,
        "audit_log": audit(
            APPOINTMENT_AGENT,
            f"Miss #{missed_count} recorded; patient notified ({notification.status}); rescheduling allowed",
            now,
        ),
    }


def _handle_reschedule(state: CareState, appointment: AppointmentRecord, now: datetime) -> dict[str, Any]:
    payload = ReschedulePayload.model_validate(state.event.payload)
    if appointment.status == AppointmentStatus.COMPLETED:
        return _reject("Completed appointments cannot be rescheduled", now)

    updated = appointment.model_copy(
        update={
            "status": AppointmentStatus.RESCHEDULED,
            "scheduled_at": payload.new_scheduled_at,
            "reschedule_count": appointment.reschedule_count + 1,
            "reschedule_allowed": False,
            "attended_at": None,
            "updated_at": now,
        }
    )
    return {
        "appointment": updated,
        "retry_count": 0,
        "evidence": _clear_attendance_evidence(state),
        "decision": WorkflowDecision.VERIFY,
        "task_status": TaskStatus.ESCALATED if state.has_active_escalation else TaskStatus.IN_PROGRESS,
        "audit_log": audit(APPOINTMENT_AGENT, f"Rescheduled to {payload.new_scheduled_at.isoformat()}", now),
    }


async def _handle_retry(
    state: CareState, appointment: AppointmentRecord, context: WorkflowContext, now: datetime
) -> dict[str, Any]:
    failed_target = state.verification.target
    latest = state.latest_patient_notification()

    if failed_target == VerificationTarget.PATIENT_NOTIFICATION and latest and latest.status == NotificationStatus.FAILED:
        resent = await context.notifications.resend(latest)
        return {
            "notifications": [resent],
            "decision": WorkflowDecision.VERIFY,
            "audit_log": audit(APPOINTMENT_AGENT, f"Retry #{state.retry_count}: resent patient notification ({resent.status})", now),
        }

    missed_in_this_run = state.event is not None and state.event.type == EventType.APPOINTMENT_STATUS_UPDATE
    if appointment.status == AppointmentStatus.MISSED and not missed_in_this_run:
        reminder = await context.notifications.notify_patient(
            task_id=state.task_id,
            patient_id=state.patient_id,
            channel=state.patient_channel,
            message_type=REMINDER_MESSAGE_TYPE,
            message="Reminder: your follow-up appointment still needs to be rescheduled.",
        )
        return {
            "notifications": [reminder],
            "decision": WorkflowDecision.MONITOR,
            "task_status": TaskStatus.AWAITING_EVENT,
            "audit_log": audit(APPOINTMENT_AGENT, f"Retry #{state.retry_count}: reschedule reminder sent ({reminder.status})", now),
        }

    return {
        "decision": WorkflowDecision.MONITOR,
        "task_status": TaskStatus.AWAITING_EVENT,
        "audit_log": audit(APPOINTMENT_AGENT, f"Retry #{state.retry_count}: awaiting reschedule", now),
    }


def _clear_attendance_evidence(state: CareState) -> dict:
    return {target: ev for target, ev in state.evidence.items() if target not in ATTENDANCE_TARGETS}


def _reject(message: str, now: datetime) -> dict[str, Any]:
    logger.info("Appointment agent rejected event: %s", message)
    return {
        "error": message,
        "decision": WorkflowDecision.MONITOR,
        "audit_log": audit(APPOINTMENT_AGENT, f"Rejected: {message}", now),
    }
