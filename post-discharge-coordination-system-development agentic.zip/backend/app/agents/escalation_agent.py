"""Escalation Agent: routes unresolved tasks to staff and resolves them only after verification."""

import logging
import uuid
from datetime import datetime
from typing import Any

from langchain_core.runnables import RunnableConfig

from app.graph.context import WorkflowContext, get_context
from app.graph.routing import ESCALATION_AGENT
from app.graph.state import CareState, audit
from app.models.enums import (
    EscalationStatus,
    EventType,
    TaskStatus,
    VerificationStatus,
    WorkflowDecision,
)
from app.models.escalation import ESCALATION_TARGETS, EscalationRecord
from app.models.events import (
    EscalationAcknowledgePayload,
    EscalationRequestPayload,
    EscalationResolutionPayload,
)

logger = logging.getLogger(__name__)


async def escalation_agent(state: CareState, config: RunnableConfig) -> dict[str, Any]:
    context = get_context(config)
    now = context.clock()
    event_type = state.event.type if state.event else None

    if event_type == EventType.ESCALATION_ACKNOWLEDGED:
        return _acknowledge(state, now)
    if state.decision == WorkflowDecision.RESOLVE_ESCALATION:
        return _resolve_if_verified(state, now)
    if state.has_active_escalation:
        return _append_update(state, now)
    return await _open(state, context, now)


async def _open(state: CareState, context: WorkflowContext, now: datetime) -> dict[str, Any]:
    reason = _escalation_reason(state)
    role = ESCALATION_TARGETS[state.task_type]
    escalation = EscalationRecord(
        escalation_id=str(uuid.uuid4()),
        patient_id=state.patient_id,
        task_id=state.task_id,
        task_type=state.task_type,
        reason=reason,
        target_role=role,
        status=EscalationStatus.OPEN,
        context=_escalation_context(state),
        created_at=now,
        updated_at=now,
    )
    alert = await context.notifications.notify_staff(
        task_id=state.task_id,
        patient_id=state.patient_id,
        role=role,
        message_type="ESCALATION_OPENED",
        message=f"Escalation {escalation.escalation_id} for patient {state.patient_id}: {reason}",
    )
    logger.info("Escalation opened id=%s task=%s role=%s", escalation.escalation_id, state.task_id, role)
    return {
        "escalation": escalation,
        "escalation_required": False,
        "notifications": [alert],
        "task_status": TaskStatus.ESCALATED,
        "decision": WorkflowDecision.VERIFY,
        "audit_log": audit(ESCALATION_AGENT, f"Opened escalation to {role}: {reason}", now),
    }


def _append_update(state: CareState, now: datetime) -> dict[str, Any]:
    escalation = state.escalation
    reason = _escalation_reason(state)
    updates = [*escalation.context.get("updates", []), {"at": now.isoformat(), "reason": reason}]
    updated = escalation.model_copy(
        update={"context": {**escalation.context, **_escalation_context(state), "updates": updates}, "updated_at": now}
    )
    return {
        "escalation": updated,
        "escalation_required": False,
        "task_status": TaskStatus.ESCALATED,
        "decision": WorkflowDecision.VERIFY,
        "audit_log": audit(ESCALATION_AGENT, f"Added context to open escalation: {reason}", now),
    }


def _acknowledge(state: CareState, now: datetime) -> dict[str, Any]:
    payload = EscalationAcknowledgePayload.model_validate(state.event.payload)
    escalation = state.escalation
    if escalation is None or escalation.escalation_id != payload.escalation_id or not escalation.is_active:
        return _reject("No active escalation with that id on this task", now)

    updated = escalation.model_copy(
        update={"status": EscalationStatus.IN_PROGRESS, "acknowledged_by": payload.staff_id, "updated_at": now}
    )
    return {
        "escalation": updated,
        "task_status": TaskStatus.ESCALATED,
        "decision": WorkflowDecision.VERIFY,
        "audit_log": audit(ESCALATION_AGENT, f"{escalation.target_role} {payload.staff_id} is working the escalation", now),
    }


def _resolve_if_verified(state: CareState, now: datetime) -> dict[str, Any]:
    escalation = state.escalation
    if escalation is None or not escalation.is_active:
        return _reject("No active escalation to resolve", now)

    note: str | None = None
    if state.event and state.event.type == EventType.ESCALATION_RESOLUTION_REQUESTED:
        payload = EscalationResolutionPayload.model_validate(state.event.payload)
        if payload.escalation_id != escalation.escalation_id:
            return _reject("Escalation id does not match this task", now)
        note = payload.note

    verification = state.verification
    if verification.status != VerificationStatus.VERIFIED:
        return _reject(
            f"Escalation cannot be resolved: {verification.target} verification is {verification.status}", now
        )

    resolved = escalation.model_copy(
        update={
            "status": EscalationStatus.RESOLVED,
            "resolved_at": now,
            "resolution_note": note or f"{verification.target} verified",
            "updated_at": now,
        }
    )
    logger.info("Escalation resolved id=%s after %s verified", escalation.escalation_id, verification.target)
    return {
        "escalation": resolved,
        "task_status": TaskStatus.COMPLETED,
        "completed_at": now,
        "decision": WorkflowDecision.COMPLETE,
        "audit_log": audit(ESCALATION_AGENT, f"Resolved after {verification.target} was VERIFIED", now),
    }


def _escalation_reason(state: CareState) -> str:
    if state.event and state.event.type == EventType.ESCALATION_REQUESTED:
        return EscalationRequestPayload.model_validate(state.event.payload).reason
    if state.escalation_reason:
        return state.escalation_reason
    return (
        f"Verification of {state.verification.target} still {state.verification.status} "
        f"after {state.retry_count} retries"
    )


def _escalation_context(state: CareState) -> dict[str, Any]:
    context: dict[str, Any] = {
        "retry_count": state.retry_count,
        "verification_status": state.verification.status,
        "verification_target": state.verification.target,
    }
    if state.appointment:
        context |= {
            "appointment_id": state.appointment.appointment_id,
            "missed_count": state.appointment.missed_count,
            "scheduled_at": state.appointment.scheduled_at.isoformat(),
        }
    if state.medication:
        deadline = state.medication.collection_deadline
        context |= {
            "medication_id": state.medication.medication_id,
            "medication_name": state.medication.name,
            "availability": state.medication.availability,
            "collection_deadline": deadline.isoformat() if deadline else None,
        }
    return context


def _reject(message: str, now: datetime) -> dict[str, Any]:
    logger.info("Escalation agent rejected request: %s", message)
    return {
        "error": message,
        "decision": WorkflowDecision.MONITOR,
        "audit_log": audit(ESCALATION_AGENT, f"Rejected: {message}", now),
    }
