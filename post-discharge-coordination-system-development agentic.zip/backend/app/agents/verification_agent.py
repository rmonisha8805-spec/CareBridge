"""Verification Agent: confirms that intended care actions actually happened.

Requests and notifications are never treated as proof of completion.
"""

import logging
from datetime import datetime
from typing import Any

from langchain_core.runnables import RunnableConfig

from app.graph.context import get_context
from app.graph.routing import VERIFICATION_AGENT, decide_after_verification
from app.graph.state import CareState, audit
from app.models.appointment import AppointmentRecord
from app.models.enums import (
    AppointmentStatus,
    EvidenceOutcome,
    EventType,
    MedicationStatus,
    NotificationStatus,
    TaskStatus,
    TaskType,
    VerificationStatus,
    VerificationTarget,
    WorkflowDecision,
)
from app.models.events import WorkflowEvent
from app.models.medication import MedicationRecord
from app.models.verification import VerificationEvidence, VerificationRecord, VerificationState

logger = logging.getLogger(__name__)


async def verification_agent(state: CareState, config: RunnableConfig) -> dict[str, Any]:
    context = get_context(config)
    now = context.clock()

    evidence = _merge_submitted_evidence(state.evidence, state.event)
    records = build_checklist(state, evidence, now)
    status, target = summarize(records)

    decision = decide_after_verification(state, status, context.settings.max_retries)
    retry_count = state.retry_count + 1 if decision == WorkflowDecision.RETRY else state.retry_count

    verification = VerificationState(
        status=status,
        target=target,
        records={record.target: record for record in records},
        last_checked_at=now,
    )
    summary = ", ".join(f"{r.target}={r.status}" for r in records)
    logger.info("Verification task=%s %s -> %s", state.task_id, summary, decision)

    return {
        "verification": verification,
        "evidence": evidence,
        "decision": decision,
        "retry_count": retry_count,
        "task_status": _task_status_for(decision, state),
        "completed_at": now if decision == WorkflowDecision.COMPLETE else state.completed_at,
        "audit_log": audit(VERIFICATION_AGENT, f"{status} on {target}: [{summary}] -> {decision}", now),
    }


def build_checklist(
    state: CareState, evidence: dict[VerificationTarget, VerificationEvidence], now: datetime
) -> list[VerificationRecord]:
    """Ordered checks; the final entry is the primary target that completes the task."""
    records: list[VerificationRecord] = []
    notification_record = check_patient_notification(state, now)

    if state.task_type == TaskType.APPOINTMENT and state.appointment is not None:
        if notification_record:
            records.append(notification_record)
        records.append(check_attendance(state.appointment, evidence, now))
    elif state.task_type == TaskType.MEDICATION and state.medication is not None:
        records.append(check_availability(state.medication, evidence, now))
        if notification_record:
            records.append(notification_record)
        elif state.medication.is_available:
            records.append(_record(VerificationTarget.PATIENT_NOTIFICATION, VerificationStatus.PENDING, "Patient not yet notified", now))
        records.append(check_collection(state.medication, evidence, now))
    return records


def summarize(records: list[VerificationRecord]) -> tuple[VerificationStatus, VerificationTarget | None]:
    if not records:
        return VerificationStatus.PENDING, None
    primary = records[-1]
    if primary.status == VerificationStatus.VERIFIED:
        return VerificationStatus.VERIFIED, primary.target
    for record in records:
        if record.status == VerificationStatus.FAILED:
            return VerificationStatus.FAILED, record.target
    first_pending = next(r for r in records if r.status == VerificationStatus.PENDING)
    return VerificationStatus.PENDING, first_pending.target


def check_attendance(
    appointment: AppointmentRecord, evidence: dict[VerificationTarget, VerificationEvidence], now: datetime
) -> VerificationRecord:
    target = appointment.attendance_target
    if override := _from_evidence(target, evidence, now):
        return override
    if appointment.status == AppointmentStatus.COMPLETED and appointment.attended_at is not None:
        return _record(target, VerificationStatus.VERIFIED, f"Attendance recorded at {appointment.attended_at.isoformat()}", now, appointment.attendance_source)
    if appointment.status == AppointmentStatus.MISSED:
        return _record(target, VerificationStatus.FAILED, f"Appointment missed (miss #{appointment.missed_count})", now)
    return _record(target, VerificationStatus.PENDING, f"Awaiting attendance for {appointment.scheduled_at.isoformat()}", now)


def check_patient_notification(state: CareState, now: datetime) -> VerificationRecord | None:
    latest = state.latest_patient_notification()
    if latest is None:
        return None
    target = VerificationTarget.PATIENT_NOTIFICATION
    if latest.status == NotificationStatus.SENT:
        return _record(target, VerificationStatus.VERIFIED, f"{latest.message_type} delivered via {latest.channel}", now)
    return _record(target, VerificationStatus.FAILED, f"{latest.message_type} failed: {latest.error}", now)


def check_availability(
    medication: MedicationRecord, evidence: dict[VerificationTarget, VerificationEvidence], now: datetime
) -> VerificationRecord:
    target = VerificationTarget.MEDICATION_AVAILABILITY
    if override := _from_evidence(target, evidence, now):
        return override
    if medication.availability == MedicationStatus.RESTOCKED:
        return _record(target, VerificationStatus.VERIFIED, "Medication restocked", now)
    if medication.availability == MedicationStatus.IN_STOCK:
        return _record(target, VerificationStatus.VERIFIED, "Medication in stock", now)
    return _record(target, VerificationStatus.PENDING, f"Medication {medication.availability}; monitoring", now)


def check_collection(
    medication: MedicationRecord, evidence: dict[VerificationTarget, VerificationEvidence], now: datetime
) -> VerificationRecord:
    target = VerificationTarget.MEDICATION_COLLECTION
    if override := _from_evidence(target, evidence, now):
        return override
    if medication.is_collected:
        return _record(target, VerificationStatus.VERIFIED, f"Collected at {medication.collected_at.isoformat()}", now, medication.collection_source)
    if medication.follow_up_expired(now):
        return _record(target, VerificationStatus.FAILED, "Not collected within follow-up period", now)
    if not medication.is_available:
        return _record(target, VerificationStatus.PENDING, "Collection not possible until medication is available", now)
    return _record(target, VerificationStatus.PENDING, "Patient notified; collection not yet observed", now)


def _merge_submitted_evidence(
    existing: dict[VerificationTarget, VerificationEvidence], event: WorkflowEvent | None
) -> dict[VerificationTarget, VerificationEvidence]:
    if event is None or event.type != EventType.VERIFICATION_EVIDENCE:
        return existing
    submitted = VerificationEvidence.model_validate(event.payload)
    return {**existing, submitted.target: submitted}


def _from_evidence(
    target: VerificationTarget, evidence: dict[VerificationTarget, VerificationEvidence], now: datetime
) -> VerificationRecord | None:
    item = evidence.get(target)
    if item is None:
        return None
    status = VerificationStatus.VERIFIED if item.outcome == EvidenceOutcome.CONFIRMED else VerificationStatus.FAILED
    reason = f"{item.outcome} by {item.source}" + (f": {item.notes}" if item.notes else "")
    return _record(target, status, reason, now, item.source)


def _record(
    target: VerificationTarget, status: VerificationStatus, reason: str, now: datetime, source: str | None = None
) -> VerificationRecord:
    return VerificationRecord(target=target, status=status, reason=reason, checked_at=now, evidence_source=source)


def _task_status_for(decision: WorkflowDecision, state: CareState) -> TaskStatus:
    if decision == WorkflowDecision.COMPLETE:
        return TaskStatus.COMPLETED
    if state.has_active_escalation:
        return TaskStatus.ESCALATED
    if decision == WorkflowDecision.MONITOR:
        return TaskStatus.AWAITING_EVENT
    return TaskStatus.IN_PROGRESS
