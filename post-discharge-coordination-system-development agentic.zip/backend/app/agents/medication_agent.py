"""Medication Agent: tracks stock, restocking, patient notice and actual collection."""

import logging
from datetime import datetime, timedelta
from typing import Any

from langchain_core.runnables import RunnableConfig

from app.graph.context import WorkflowContext, get_context
from app.graph.routing import MEDICATION_AGENT
from app.graph.state import AuditEntry, CareState, audit
from app.models.enums import (
    CollectionStatus,
    EventType,
    MedicationStatus,
    NotificationStatus,
    TaskStatus,
    VerificationTarget,
    WorkflowDecision,
)
from app.models.events import AvailabilityPayload, CollectionPayload
from app.models.medication import MedicationRecord

logger = logging.getLogger(__name__)

READY_MESSAGE_TYPE = "MEDICATION_READY_FOR_COLLECTION"
REMINDER_MESSAGE_TYPE = "MEDICATION_COLLECTION_REMINDER"


async def medication_agent(state: CareState, config: RunnableConfig) -> dict[str, Any]:
    context = get_context(config)
    now = context.clock()
    if state.medication is None:
        return _reject("Task has no medication to track", now)

    if state.decision == WorkflowDecision.RETRY:
        return await _handle_retry(state, state.medication, context, now)

    event_type = state.event.type if state.event else EventType.START
    if event_type == EventType.MEDICATION_COLLECTION_UPDATE:
        updates = _handle_collection(state, state.medication, now)
    elif event_type in (EventType.START, EventType.MEDICATION_AVAILABILITY_UPDATE):
        updates = await _handle_availability(state, state.medication, context, now)
    else:
        updates = {"audit_log": audit(MEDICATION_AGENT, f"Monitoring check ({state.medication.availability})", now)}

    if "error" in updates:
        return updates
    return _apply_follow_up_rule(state, updates, context, now)


async def _handle_availability(
    state: CareState, medication: MedicationRecord, context: WorkflowContext, now: datetime
) -> dict[str, Any]:
    if medication.is_collected:
        return _reject("Medication has already been collected", now)

    if state.event and state.event.type == EventType.MEDICATION_AVAILABILITY_UPDATE:
        payload = AvailabilityPayload.model_validate(state.event.payload)
        available, source = payload.available, payload.source
    elif medication.availability == MedicationStatus.UNKNOWN:
        return {"audit_log": audit(MEDICATION_AGENT, "Availability unknown; awaiting pharmacy update", now)}
    else:
        available, source = medication.is_available, "initial prescription check"

    if not available:
        if medication.availability == MedicationStatus.OUT_OF_STOCK:
            return {"audit_log": audit(MEDICATION_AGENT, "Still out of stock; continuing to monitor", now)}
        updated = medication.model_copy(
            update={
                "availability": MedicationStatus.OUT_OF_STOCK,
                "out_of_stock_since": now,
                "available_since": None,
                "collection_deadline": None,
                "updated_at": now,
            }
        )
        return {"medication": updated, "audit_log": audit(MEDICATION_AGENT, f"Out of stock (source: {source})", now)}

    if medication.is_available and medication.patient_notified_at is not None:
        return {"audit_log": audit(MEDICATION_AGENT, "Availability unchanged; no duplicate notification", now)}

    restocked = medication.availability == MedicationStatus.OUT_OF_STOCK
    deadline = now + timedelta(hours=context.settings.medication_follow_up_hours)
    notification = await context.notifications.notify_patient(
        task_id=state.task_id,
        patient_id=state.patient_id,
        channel=state.patient_channel,
        message_type=READY_MESSAGE_TYPE,
        message=f"Your medication {medication.name} is ready for collection"
        + (f" at {medication.pharmacy}." if medication.pharmacy else "."),
    )
    updated = medication.model_copy(
        update={
            "availability": MedicationStatus.RESTOCKED if restocked else MedicationStatus.IN_STOCK,
            "available_since": now,
            "restocked_at": now if restocked else medication.restocked_at,
            "patient_notified_at": now,
            "collection_deadline": deadline,
            "updated_at": now,
        }
    )
    label = "Restocked" if restocked else "Available"
    return {
        "medication": updated,
        "retry_count": 0,
        "notifications": [notification],
        "audit_log": audit(
            MEDICATION_AGENT,
            f"{label} (source: {source}); patient notified ({notification.status}); collect by {deadline.isoformat()}",
            now,
        ),
    }


def _handle_collection(state: CareState, medication: MedicationRecord, now: datetime) -> dict[str, Any]:
    payload = CollectionPayload.model_validate(state.event.payload)
    if not medication.is_available:
        return _reject("Medication cannot be collected while it is not available", now)
    if medication.is_collected:
        return _reject("Medication collection is already recorded", now)
    if not payload.collected:
        return {"audit_log": audit(MEDICATION_AGENT, f"Collection not observed (source: {payload.source})", now)}

    updated = medication.model_copy(
        update={
            "collection_status": CollectionStatus.COLLECTED,
            "collected_at": payload.collected_at or now,
            "collection_source": payload.source,
            "updated_at": now,
        }
    )
    evidence = {t: e for t, e in state.evidence.items() if t != VerificationTarget.MEDICATION_COLLECTION}
    return {
        "medication": updated,
        "evidence": evidence,
        "audit_log": audit(MEDICATION_AGENT, f"Collection reported by {payload.source}", now),
    }


def _apply_follow_up_rule(
    state: CareState, updates: dict[str, Any], context: WorkflowContext, now: datetime
) -> dict[str, Any]:
    medication: MedicationRecord = updates.get("medication", state.medication)
    log: list[AuditEntry] = list(updates.get("audit_log", []))

    if medication.follow_up_expired(now) and not state.has_active_escalation:
        hours = context.settings.medication_follow_up_hours
        log += audit(MEDICATION_AGENT, f"Not collected within {hours:g}h follow-up period", now)
        return {
            **updates,
            "audit_log": log,
            "escalation_required": True,
            "escalation_reason": f"Medication {medication.name} not collected within {hours:g}h of availability",
            "decision": WorkflowDecision.ESCALATE,
        }
    return {**updates, "audit_log": log, "decision": WorkflowDecision.VERIFY}


async def _handle_retry(
    state: CareState, medication: MedicationRecord, context: WorkflowContext, now: datetime
) -> dict[str, Any]:
    failed_target = state.verification.target
    latest = state.latest_patient_notification()

    if failed_target == VerificationTarget.PATIENT_NOTIFICATION and latest and latest.status == NotificationStatus.FAILED:
        resent = await context.notifications.resend(latest)
        return {
            "notifications": [resent],
            "decision": WorkflowDecision.VERIFY,
            "audit_log": audit(MEDICATION_AGENT, f"Retry #{state.retry_count}: resent patient notification ({resent.status})", now),
        }

    if failed_target == VerificationTarget.MEDICATION_COLLECTION and medication.is_available:
        reminder = await context.notifications.notify_patient(
            task_id=state.task_id,
            patient_id=state.patient_id,
            channel=state.patient_channel,
            message_type=REMINDER_MESSAGE_TYPE,
            message=f"Reminder: your medication {medication.name} is still waiting for collection.",
        )
        return {
            "notifications": [reminder],
            "decision": WorkflowDecision.MONITOR,
            "task_status": TaskStatus.AWAITING_EVENT,
            "audit_log": audit(MEDICATION_AGENT, f"Retry #{state.retry_count}: collection reminder sent ({reminder.status})", now),
        }

    return {
        "decision": WorkflowDecision.MONITOR,
        "task_status": TaskStatus.AWAITING_EVENT,
        "audit_log": audit(MEDICATION_AGENT, f"Retry #{state.retry_count}: continuing to monitor", now),
    }


def _reject(message: str, now: datetime) -> dict[str, Any]:
    logger.info("Medication agent rejected event: %s", message)
    return {
        "error": message,
        "decision": WorkflowDecision.MONITOR,
        "audit_log": audit(MEDICATION_AGENT, f"Rejected: {message}", now),
    }
