from langgraph.graph import END, START, StateGraph
from langgraph.graph.state import CompiledStateGraph

from app.agents.appointment_agent import appointment_agent
from app.agents.escalation_agent import escalation_agent
from app.agents.medication_agent import medication_agent
from app.agents.verification_agent import verification_agent
from app.graph.routing import (
    APPOINTMENT_AGENT,
    ESCALATION_AGENT,
    MEDICATION_AGENT,
    VERIFICATION_AGENT,
    route_after_domain_agent,
    route_after_escalation,
    route_after_verification,
    route_entry,
)
from app.graph.state import CareState


def build_care_workflow() -> CompiledStateGraph:
    """Compile the four-agent care coordination graph.

    START ─┬─> appointment_agent ─┐
           ├─> medication_agent ──┼─> verification_agent ─┬─> END (complete / monitor)
           ├─> verification_agent │        ▲              ├─> domain agent (retry)
           └─> escalation_agent <─┘        │              └─> escalation_agent
                     └─────────────────────┘ (re-verify before any resolution)
    """
    graph = StateGraph(CareState)

    graph.add_node(APPOINTMENT_AGENT, appointment_agent)
    graph.add_node(MEDICATION_AGENT, medication_agent)
    graph.add_node(VERIFICATION_AGENT, verification_agent)
    graph.add_node(ESCALATION_AGENT, escalation_agent)

    graph.add_conditional_edges(
        START,
        route_entry,
        [APPOINTMENT_AGENT, MEDICATION_AGENT, VERIFICATION_AGENT, ESCALATION_AGENT, END],
    )
    for domain_agent in (APPOINTMENT_AGENT, MEDICATION_AGENT):
        graph.add_conditional_edges(domain_agent, route_after_domain_agent, [VERIFICATION_AGENT, ESCALATION_AGENT, END])

    graph.add_conditional_edges(
        VERIFICATION_AGENT,
        route_after_verification,
        [APPOINTMENT_AGENT, MEDICATION_AGENT, ESCALATION_AGENT, END],
    )
    graph.add_conditional_edges(ESCALATION_AGENT, route_after_escalation, [VERIFICATION_AGENT, END])

    return graph.compile()
