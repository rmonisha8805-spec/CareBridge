import operator
from datetime import datetime
from typing import Annotated

from pydantic import BaseModel, Field

from app.models.appointment import AppointmentRecord
from app.models.enums import (
    NotificationChannel,
    RecipientType,
    TaskStatus,
    TaskType,
    VerificationTarget,
    WorkflowDecision,
)
from app.models.escalation import EscalationRecord
from app.models.events import WorkflowEvent
from app.models.medication import MedicationRecord
from app.models.notification import NotificationRecord
from app.models.verification import VerificationEvidence, VerificationState


class AuditEntry(BaseModel):
    at: datetime
    node: str
    message: str


class CareState(BaseModel):
    """Shared LangGraph state for one care task (a follow-up appointment or a medication)."""

    task_id: str
    patient_id: str
    task_type: TaskType
    task_status: TaskStatus = TaskStatus.IN_PROGRESS
    patient_channel: NotificationChannel | None = None

    appointment: AppointmentRecord | None = None
    medication: MedicationRecord | None = None

    event: WorkflowEvent | None = None
    decision: WorkflowDecision | None = None
    retry_count: int = 0

    verification: VerificationState = Field(default_factory=VerificationState)
    evidence: dict[VerificationTarget, VerificationEvidence] = Field(default_factory=dict)

    escalation_required: bool = False
    escalation_reason: str | None = None
    escalation: EscalationRecord | None = None

    notifications: Annotated[list[NotificationRecord], operator.add] = Field(default_factory=list)
    audit_log: Annotated[list[AuditEntry], operator.add] = Field(default_factory=list)

    error: str | None = None
    created_at: datetime
    updated_at: datetime
    completed_at: datetime | None = None

    @property
    def has_active_escalation(self) -> bool:
        return self.escalation is not None and self.escalation.is_active

    def latest_patient_notification(self) -> NotificationRecord | None:
        for notification in reversed(self.notifications):
            if notification.recipient_type == RecipientType.PATIENT:
                return notification
        return None


def audit(node: str, message: str, at: datetime) -> list[AuditEntry]:
    return [AuditEntry(at=at, node=node, message=message)]
