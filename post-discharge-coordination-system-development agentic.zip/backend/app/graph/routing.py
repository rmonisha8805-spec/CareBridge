"""Deterministic workflow rules and LangGraph conditional-edge routers.

No LLM is involved in any decision in this module.
"""

from langgraph.graph import END

from app.graph.state import CareState
from app.models.enums import EventType, TaskStatus, TaskType, VerificationStatus, WorkflowDecision

APPOINTMENT_AGENT = "appointment_agent"
MEDICATION_AGENT = "medication_agent"
VERIFICATION_AGENT = "verification_agent"
ESCALATION_AGENT = "escalation_agent"

DOMAIN_AGENTS: dict[TaskType, str] = {
    TaskType.APPOINTMENT: APPOINTMENT_AGENT,
    TaskType.MEDICATION: MEDICATION_AGENT,
}

VERIFICATION_ENTRY_EVENTS = frozenset({EventType.VERIFICATION_EVIDENCE, EventType.ESCALATION_RESOLUTION_REQUESTED})
ESCALATION_ENTRY_EVENTS = frozenset({EventType.ESCALATION_REQUESTED, EventType.ESCALATION_ACKNOWLEDGED})


def appointment_requires_escalation(missed_count: int, threshold: int) -> bool:
    return missed_count >= threshold


def decide_after_verification(
    state: CareState, status: VerificationStatus, max_retries: int
) -> WorkflowDecision:
    active_escalation = state.has_active_escalation
    resolution_requested = state.event is not None and state.event.type == EventType.ESCALATION_RESOLUTION_REQUESTED

    if status == VerificationStatus.VERIFIED:
        return WorkflowDecision.RESOLVE_ESCALATION if active_escalation else WorkflowDecision.COMPLETE
    if active_escalation:
        return WorkflowDecision.RESOLVE_ESCALATION if resolution_requested else WorkflowDecision.MONITOR
    if state.escalation_required:
        return WorkflowDecision.ESCALATE
    if status == VerificationStatus.PENDING:
        return WorkflowDecision.MONITOR
    if state.retry_count >= max_retries:
        return WorkflowDecision.ESCALATE
    return WorkflowDecision.RETRY


def route_entry(state: CareState) -> str:
    if state.task_status == TaskStatus.COMPLETED or state.event is None:
        return END
    if state.event.type in VERIFICATION_ENTRY_EVENTS:
        return VERIFICATION_AGENT
    if state.event.type in ESCALATION_ENTRY_EVENTS:
        return ESCALATION_AGENT
    return DOMAIN_AGENTS[state.task_type]


def route_after_domain_agent(state: CareState) -> str:
    match state.decision:
        case WorkflowDecision.VERIFY:
            return VERIFICATION_AGENT
        case WorkflowDecision.ESCALATE:
            return ESCALATION_AGENT
        case _:
            return END


def route_after_verification(state: CareState) -> str:
    match state.decision:
        case WorkflowDecision.RETRY:
            return DOMAIN_AGENTS[state.task_type]
        case WorkflowDecision.ESCALATE | WorkflowDecision.RESOLVE_ESCALATION:
            return ESCALATION_AGENT
        case _:
            return END


def route_after_escalation(state: CareState) -> str:
    if state.decision == WorkflowDecision.VERIFY:
        return VERIFICATION_AGENT
    return END
