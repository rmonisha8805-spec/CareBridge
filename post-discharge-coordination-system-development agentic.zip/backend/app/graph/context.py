from dataclasses import dataclass

from langchain_core.runnables import RunnableConfig

from app.config import Settings
from app.services.clock import Clock
from app.services.notification_service import NotificationService

CONTEXT_KEY = "care_context"


@dataclass(frozen=True)
class WorkflowContext:
    """Dependencies injected into graph nodes through the LangGraph run config."""

    settings: Settings
    notifications: NotificationService
    clock: Clock


def get_context(config: RunnableConfig) -> WorkflowContext:
    context = config.get("configurable", {}).get(CONTEXT_KEY)
    if not isinstance(context, WorkflowContext):
        raise RuntimeError("WorkflowContext missing from graph config")
    return context


def build_run_config(context: WorkflowContext) -> RunnableConfig:
    return {
        "configurable": {CONTEXT_KEY: context},
        "recursion_limit": context.settings.graph_recursion_limit,
    }
