import asyncio
import logging
from collections.abc import AsyncIterator, Iterable
from contextlib import asynccontextmanager
from typing import Any

import aiosqlite

logger = logging.getLogger(__name__)

SCHEMA = """
CREATE TABLE IF NOT EXISTS care_tasks (
    task_id TEXT PRIMARY KEY,
    patient_id TEXT NOT NULL,
    task_type TEXT NOT NULL,
    task_status TEXT NOT NULL,
    state_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_care_tasks_patient ON care_tasks (patient_id);

CREATE TABLE IF NOT EXISTS appointments (
    appointment_id TEXT PRIMARY KEY,
    task_id TEXT NOT NULL REFERENCES care_tasks (task_id),
    patient_id TEXT NOT NULL,
    status TEXT NOT NULL,
    scheduled_at TEXT NOT NULL,
    missed_count INTEGER NOT NULL,
    reschedule_count INTEGER NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS medications (
    medication_id TEXT PRIMARY KEY,
    task_id TEXT NOT NULL REFERENCES care_tasks (task_id),
    patient_id TEXT NOT NULL,
    name TEXT NOT NULL,
    availability TEXT NOT NULL,
    collection_status TEXT NOT NULL,
    collection_deadline TEXT,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS verification_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id TEXT NOT NULL REFERENCES care_tasks (task_id),
    target TEXT NOT NULL,
    status TEXT NOT NULL,
    reason TEXT NOT NULL,
    evidence_source TEXT,
    checked_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_verification_task ON verification_records (task_id);

CREATE TABLE IF NOT EXISTS escalations (
    escalation_id TEXT PRIMARY KEY,
    task_id TEXT NOT NULL REFERENCES care_tasks (task_id),
    patient_id TEXT NOT NULL,
    task_type TEXT NOT NULL,
    target_role TEXT NOT NULL,
    status TEXT NOT NULL,
    record_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_escalations_status ON escalations (status);

CREATE TABLE IF NOT EXISTS notifications (
    notification_id TEXT PRIMARY KEY,
    task_id TEXT NOT NULL REFERENCES care_tasks (task_id),
    patient_id TEXT NOT NULL,
    recipient_type TEXT NOT NULL,
    recipient_role TEXT,
    channel TEXT,
    message_type TEXT NOT NULL,
    status TEXT NOT NULL,
    error TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_notifications_task ON notifications (task_id);
"""


def sqlite_path(database_url: str) -> str:
    prefix = "sqlite:///"
    if not database_url.startswith(prefix):
        raise ValueError("Only sqlite:/// database URLs are supported by the development persistence layer")
    return database_url.removeprefix(prefix)


class Database:
    def __init__(self, database_url: str) -> None:
        self._path = sqlite_path(database_url)
        self._connection: aiosqlite.Connection | None = None
        self._write_lock = asyncio.Lock()

    async def connect(self) -> None:
        self._connection = await aiosqlite.connect(self._path)
        self._connection.row_factory = aiosqlite.Row
        await self._connection.execute("PRAGMA foreign_keys = ON")
        await self._connection.executescript(SCHEMA)
        await self._connection.commit()
        logger.info("Database ready at %s", self._path)

    async def close(self) -> None:
        if self._connection is not None:
            await self._connection.close()
            self._connection = None

    @property
    def connection(self) -> aiosqlite.Connection:
        if self._connection is None:
            raise RuntimeError("Database is not connected")
        return self._connection

    @asynccontextmanager
    async def transaction(self) -> AsyncIterator[aiosqlite.Connection]:
        async with self._write_lock:
            try:
                yield self.connection
                await self.connection.commit()
            except Exception:
                await self.connection.rollback()
                raise

    async def fetch_one(self, sql: str, params: Iterable[Any] = ()) -> aiosqlite.Row | None:
        async with self.connection.execute(sql, tuple(params)) as cursor:
            return await cursor.fetchone()

    async def fetch_all(self, sql: str, params: Iterable[Any] = ()) -> list[aiosqlite.Row]:
        async with self.connection.execute(sql, tuple(params)) as cursor:
            return list(await cursor.fetchall())
