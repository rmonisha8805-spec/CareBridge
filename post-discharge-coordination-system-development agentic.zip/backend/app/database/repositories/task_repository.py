import aiosqlite

from app.database.database import Database
from app.graph.state import CareState


class TaskRepository:
    def __init__(self, db: Database) -> None:
        self._db = db

    async def upsert(self, conn: aiosqlite.Connection, state: CareState) -> None:
        await conn.execute(
            """
            INSERT INTO care_tasks (task_id, patient_id, task_type, task_status, state_json, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT (task_id) DO UPDATE SET
                task_status = excluded.task_status,
                state_json = excluded.state_json,
                updated_at = excluded.updated_at
            """,
            (
                state.task_id,
                state.patient_id,
                state.task_type,
                state.task_status,
                state.model_dump_json(),
                state.created_at.isoformat(),
                state.updated_at.isoformat(),
            ),
        )

    async def get(self, task_id: str) -> CareState | None:
        row = await self._db.fetch_one("SELECT state_json FROM care_tasks WHERE task_id = ?", (task_id,))
        return CareState.model_validate_json(row["state_json"]) if row else None

    async def list(self, patient_id: str | None = None) -> list[CareState]:
        if patient_id:
            rows = await self._db.fetch_all(
                "SELECT state_json FROM care_tasks WHERE patient_id = ? ORDER BY created_at", (patient_id,)
            )
        else:
            rows = await self._db.fetch_all("SELECT state_json FROM care_tasks ORDER BY created_at")
        return [CareState.model_validate_json(row["state_json"]) for row in rows]
