import aiosqlite

from app.database.database import Database
from app.models.enums import EscalationStatus, StaffRole
from app.models.escalation import EscalationRecord


class EscalationRepository:
    def __init__(self, db: Database) -> None:
        self._db = db

    async def upsert(self, conn: aiosqlite.Connection, escalation: EscalationRecord) -> None:
        await conn.execute(
            """
            INSERT INTO escalations (escalation_id, task_id, patient_id, task_type, target_role, status,
                                     record_json, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT (escalation_id) DO UPDATE SET
                status = excluded.status,
                record_json = excluded.record_json,
                updated_at = excluded.updated_at
            """,
            (
                escalation.escalation_id,
                escalation.task_id,
                escalation.patient_id,
                escalation.task_type,
                escalation.target_role,
                escalation.status,
                escalation.model_dump_json(),
                escalation.created_at.isoformat(),
                escalation.updated_at.isoformat(),
            ),
        )

    async def get(self, escalation_id: str) -> EscalationRecord | None:
        row = await self._db.fetch_one("SELECT record_json FROM escalations WHERE escalation_id = ?", (escalation_id,))
        return EscalationRecord.model_validate_json(row["record_json"]) if row else None

    async def list(
        self, status: EscalationStatus | None = None, target_role: StaffRole | None = None
    ) -> list[EscalationRecord]:
        clauses: list[str] = []
        params: list[str] = []
        if status:
            clauses.append("status = ?")
            params.append(status)
        if target_role:
            clauses.append("target_role = ?")
            params.append(target_role)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        rows = await self._db.fetch_all(f"SELECT record_json FROM escalations {where} ORDER BY created_at", params)
        return [EscalationRecord.model_validate_json(row["record_json"]) for row in rows]
