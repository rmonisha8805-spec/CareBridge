from collections.abc import Iterable

import aiosqlite

from app.database.database import Database
from app.models.appointment import AppointmentRecord
from app.models.medication import MedicationRecord
from app.models.notification import NotificationRecord
from app.models.verification import VerificationRecord


class CareRecordRepository:
    """Queryable snapshots of appointments, medications, verifications and notifications."""

    def __init__(self, db: Database) -> None:
        self._db = db

    async def upsert_appointment(
        self, conn: aiosqlite.Connection, task_id: str, patient_id: str, appointment: AppointmentRecord
    ) -> None:
        await conn.execute(
            """
            INSERT INTO appointments (appointment_id, task_id, patient_id, status, scheduled_at, missed_count,
                                      reschedule_count, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT (appointment_id) DO UPDATE SET
                status = excluded.status, scheduled_at = excluded.scheduled_at,
                missed_count = excluded.missed_count, reschedule_count = excluded.reschedule_count,
                updated_at = excluded.updated_at
            """,
            (
                appointment.appointment_id,
                task_id,
                patient_id,
                appointment.status,
                appointment.scheduled_at.isoformat(),
                appointment.missed_count,
                appointment.reschedule_count,
                appointment.updated_at.isoformat(),
            ),
        )

    async def upsert_medication(
        self, conn: aiosqlite.Connection, task_id: str, patient_id: str, medication: MedicationRecord
    ) -> None:
        deadline = medication.collection_deadline.isoformat() if medication.collection_deadline else None
        await conn.execute(
            """
            INSERT INTO medications (medication_id, task_id, patient_id, name, availability, collection_status,
                                     collection_deadline, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT (medication_id) DO UPDATE SET
                availability = excluded.availability, collection_status = excluded.collection_status,
                collection_deadline = excluded.collection_deadline, updated_at = excluded.updated_at
            """,
            (
                medication.medication_id,
                task_id,
                patient_id,
                medication.name,
                medication.availability,
                medication.collection_status,
                deadline,
                medication.updated_at.isoformat(),
            ),
        )

    async def add_verification_records(
        self, conn: aiosqlite.Connection, task_id: str, records: Iterable[VerificationRecord]
    ) -> None:
        await conn.executemany(
            """
            INSERT INTO verification_records (task_id, target, status, reason, evidence_source, checked_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            [(task_id, r.target, r.status, r.reason, r.evidence_source, r.checked_at.isoformat()) for r in records],
        )

    async def add_notifications(self, conn: aiosqlite.Connection, notifications: Iterable[NotificationRecord]) -> None:
        await conn.executemany(
            """
            INSERT INTO notifications (notification_id, task_id, patient_id, recipient_type, recipient_role,
                                       channel, message_type, status, error, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            [
                (
                    n.notification_id,
                    n.task_id,
                    n.patient_id,
                    n.recipient_type,
                    n.recipient_role,
                    n.channel,
                    n.message_type,
                    n.status,
                    n.error,
                    n.created_at.isoformat(),
                )
                for n in notifications
            ],
        )

    async def list_verification_records(self, task_id: str) -> list[VerificationRecord]:
        rows = await self._db.fetch_all(
            "SELECT target, status, reason, evidence_source, checked_at FROM verification_records "
            "WHERE task_id = ? ORDER BY id",
            (task_id,),
        )
        return [VerificationRecord.model_validate(dict(row)) for row in rows]
