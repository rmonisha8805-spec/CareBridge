from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, Query, status

from app.api.dependencies import get_care_service
from app.api.schemas import (
    AcknowledgeRequest,
    AppointmentStatusRequest,
    AvailabilityRequest,
    CollectionRequest,
    CreateAppointmentTaskRequest,
    CreateMedicationTaskRequest,
    ErrorResponse,
    EscalationRequest,
    EvidenceRequest,
    RescheduleRequest,
    ResolveRequest,
    TaskResponse,
)
from app.graph.state import CareState
from app.models.enums import EscalationStatus, EventType, StaffRole
from app.models.escalation import EscalationRecord
from app.models.verification import VerificationRecord
from app.services.care_task_service import CareTaskService

router = APIRouter()
Service = Annotated[CareTaskService, Depends(get_care_service)]
EVENT_RESPONSES: dict[int | str, dict[str, Any]] = {
    404: {"description": "Task not found"},
    409: {"model": ErrorResponse, "description": "Workflow rejected the event"},
    422: {"description": "Event is invalid for this task"},
}


def to_response(state: CareState) -> TaskResponse:
    return TaskResponse.model_validate(state.model_dump())


async def submit(service: CareTaskService, task_id: str, event: EventType, payload: dict, actor: str | None = None):
    return to_response(await service.submit_event(task_id, event, payload, actor))


@router.get("/health", tags=["system"])
async def health() -> dict[str, str]:
    return {"status": "ok"}


@router.post("/tasks/appointments", status_code=status.HTTP_201_CREATED, tags=["tasks"])
async def create_appointment_task(body: CreateAppointmentTaskRequest, service: Service) -> TaskResponse:
    state = await service.create_appointment_task(
        patient_id=body.patient_id,
        patient_channel=body.patient_channel,
        appointment=body.appointment.model_dump(exclude_none=True),
    )
    return to_response(state)


@router.post("/tasks/medications", status_code=status.HTTP_201_CREATED, tags=["tasks"])
async def create_medication_task(body: CreateMedicationTaskRequest, service: Service) -> TaskResponse:
    state = await service.create_medication_task(
        patient_id=body.patient_id,
        patient_channel=body.patient_channel,
        medication=body.medication.model_dump(exclude_none=True),
    )
    return to_response(state)


@router.get("/tasks", tags=["tasks"])
async def list_tasks(service: Service, patient_id: str | None = Query(default=None, max_length=128)) -> list[TaskResponse]:
    return [to_response(state) for state in await service.tasks.list(patient_id)]


@router.get("/tasks/{task_id}", responses={404: {"description": "Task not found"}}, tags=["tasks"])
async def get_task(task_id: str, service: Service) -> TaskResponse:
    return to_response(await service.get_task(task_id))


@router.get("/tasks/{task_id}/verifications", tags=["verification"])
async def list_verifications(task_id: str, service: Service) -> list[VerificationRecord]:
    await service.get_task(task_id)
    return await service.records.list_verification_records(task_id)


@router.post("/tasks/{task_id}/monitor", responses=EVENT_RESPONSES, tags=["tasks"])
async def monitor_task(task_id: str, service: Service) -> TaskResponse:
    return await submit(service, task_id, EventType.MONITOR_CHECK, {})


@router.post("/tasks/{task_id}/appointment/status", responses=EVENT_RESPONSES, tags=["appointments"])
async def report_appointment_status(task_id: str, body: AppointmentStatusRequest, service: Service) -> TaskResponse:
    return await submit(service, task_id, EventType.APPOINTMENT_STATUS_UPDATE, body.model_dump(mode="json"), body.source)


@router.post("/tasks/{task_id}/appointment/reschedule", responses=EVENT_RESPONSES, tags=["appointments"])
async def reschedule_appointment(task_id: str, body: RescheduleRequest, service: Service) -> TaskResponse:
    return await submit(service, task_id, EventType.APPOINTMENT_RESCHEDULED, body.model_dump(mode="json"))


@router.post("/tasks/{task_id}/medication/availability", responses=EVENT_RESPONSES, tags=["medications"])
async def report_medication_availability(task_id: str, body: AvailabilityRequest, service: Service) -> TaskResponse:
    return await submit(service, task_id, EventType.MEDICATION_AVAILABILITY_UPDATE, body.model_dump(mode="json"), body.source)


@router.post("/tasks/{task_id}/medication/collection", responses=EVENT_RESPONSES, tags=["medications"])
async def report_medication_collection(task_id: str, body: CollectionRequest, service: Service) -> TaskResponse:
    return await submit(service, task_id, EventType.MEDICATION_COLLECTION_UPDATE, body.model_dump(mode="json"), body.source)


@router.post("/tasks/{task_id}/verification/evidence", responses=EVENT_RESPONSES, tags=["verification"])
async def submit_verification_evidence(task_id: str, body: EvidenceRequest, service: Service) -> TaskResponse:
    payload = body.model_dump(mode="json")
    payload["observed_at"] = payload["observed_at"] or service.clock().isoformat()
    return await submit(service, task_id, EventType.VERIFICATION_EVIDENCE, payload, body.source)


@router.post("/tasks/{task_id}/escalations", responses=EVENT_RESPONSES, tags=["escalations"])
async def request_escalation(task_id: str, body: EscalationRequest, service: Service) -> TaskResponse:
    return await submit(service, task_id, EventType.ESCALATION_REQUESTED, {"reason": body.reason}, body.requested_by)


@router.get("/escalations", tags=["escalations"])
async def list_escalations(
    service: Service,
    escalation_status: Annotated[EscalationStatus | None, Query(alias="status")] = None,
    target_role: StaffRole | None = None,
) -> list[EscalationRecord]:
    return await service.escalations.list(escalation_status, target_role)


@router.post("/escalations/{escalation_id}/acknowledge", responses=EVENT_RESPONSES, tags=["escalations"])
async def acknowledge_escalation(escalation_id: str, body: AcknowledgeRequest, service: Service) -> TaskResponse:
    escalation = await _get_escalation(service, escalation_id)
    payload = {"escalation_id": escalation_id, "staff_id": body.staff_id}
    return await submit(service, escalation.task_id, EventType.ESCALATION_ACKNOWLEDGED, payload, body.staff_id)


@router.post("/escalations/{escalation_id}/resolve", responses=EVENT_RESPONSES, tags=["escalations"])
async def resolve_escalation(escalation_id: str, body: ResolveRequest, service: Service) -> TaskResponse:
    escalation = await _get_escalation(service, escalation_id)
    payload = {"escalation_id": escalation_id, "resolved_by": body.resolved_by, "note": body.note}
    return await submit(service, escalation.task_id, EventType.ESCALATION_RESOLUTION_REQUESTED, payload, body.resolved_by)


async def _get_escalation(service: CareTaskService, escalation_id: str) -> EscalationRecord:
    escalation = await service.escalations.get(escalation_id)
    if escalation is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Escalation not found")
    return escalation
