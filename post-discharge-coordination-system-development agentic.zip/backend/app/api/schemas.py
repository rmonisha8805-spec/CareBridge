from datetime import datetime
from typing import Literal

from pydantic import AwareDatetime, BaseModel, Field

from app.graph.state import AuditEntry
from app.models.appointment import AppointmentRecord
from app.models.enums import (
    AppointmentStatus,
    EvidenceOutcome,
    MedicationStatus,
    NotificationChannel,
    TaskStatus,
    TaskType,
    VerificationTarget,
    WorkflowDecision,
)
from app.models.escalation import EscalationRecord
from app.models.medication import MedicationRecord
from app.models.notification import NotificationRecord
from app.models.verification import VerificationState

IdStr = Field(min_length=1, max_length=128)
SourceStr = Field(min_length=1, max_length=200)


class AppointmentInput(BaseModel):
    appointment_id: str | None = Field(default=None, min_length=1, max_length=128)
    scheduled_at: AwareDatetime
    provider: str | None = Field(default=None, max_length=200)
    location: str | None = Field(default=None, max_length=200)


class MedicationInput(BaseModel):
    medication_id: str | None = Field(default=None, min_length=1, max_length=128)
    name: str = Field(min_length=1, max_length=200)
    dosage: str | None = Field(default=None, max_length=200)
    pharmacy: str | None = Field(default=None, max_length=200)
    availability: Literal[MedicationStatus.UNKNOWN, MedicationStatus.IN_STOCK, MedicationStatus.OUT_OF_STOCK] = (
        MedicationStatus.UNKNOWN
    )


class CreateAppointmentTaskRequest(BaseModel):
    patient_id: str = IdStr
    patient_channel: NotificationChannel | None = None
    appointment: AppointmentInput


class CreateMedicationTaskRequest(BaseModel):
    patient_id: str = IdStr
    patient_channel: NotificationChannel | None = None
    medication: MedicationInput


class AppointmentStatusRequest(BaseModel):
    status: Literal[AppointmentStatus.COMPLETED, AppointmentStatus.MISSED]
    occurred_at: AwareDatetime | None = None
    source: str = SourceStr


class RescheduleRequest(BaseModel):
    new_scheduled_at: AwareDatetime
    reason: str | None = Field(default=None, max_length=500)


class AvailabilityRequest(BaseModel):
    available: bool
    source: str = SourceStr


class CollectionRequest(BaseModel):
    collected: bool
    collected_at: AwareDatetime | None = None
    source: str = SourceStr


class EvidenceRequest(BaseModel):
    target: VerificationTarget
    outcome: EvidenceOutcome
    source: str = SourceStr
    notes: str | None = Field(default=None, max_length=1000)
    observed_at: AwareDatetime | None = None


class EscalationRequest(BaseModel):
    reason: str = Field(min_length=1, max_length=1000)
    requested_by: str = IdStr


class AcknowledgeRequest(BaseModel):
    staff_id: str = IdStr


class ResolveRequest(BaseModel):
    resolved_by: str = IdStr
    note: str | None = Field(default=None, max_length=1000)


class TaskResponse(BaseModel):
    task_id: str
    patient_id: str
    task_type: TaskType
    task_status: TaskStatus
    decision: WorkflowDecision | None
    retry_count: int
    appointment: AppointmentRecord | None
    medication: MedicationRecord | None
    verification: VerificationState
    escalation: EscalationRecord | None
    notifications: list[NotificationRecord]
    audit_log: list[AuditEntry]
    error: str | None
    created_at: datetime
    updated_at: datetime
    completed_at: datetime | None


class ErrorResponse(BaseModel):
    detail: str
    task: TaskResponse | None = None
