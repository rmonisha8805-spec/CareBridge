from fastapi import Request

from app.services.care_task_service import CareTaskService


def get_care_service(request: Request) -> CareTaskService:
    return request.app.state.care_service
