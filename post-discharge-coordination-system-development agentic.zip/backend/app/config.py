from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Runtime configuration, loaded from environment variables or a local .env file."""

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_name: str = "Post-Discharge Care Coordination Backend"
    log_level: str = "INFO"

    database_url: str = "sqlite:///./care_coordination.db"

    max_retries: int = Field(default=3, ge=0, le=20)
    appointment_escalation_threshold: int = Field(default=2, ge=1)
    medication_follow_up_hours: float = Field(default=72, gt=0)
    graph_recursion_limit: int = Field(default=50, ge=10)

    notification_dispatcher: str = "log"
    staff_notification_channel: str = "INTERNAL_QUEUE"


@lru_cache
def get_settings() -> Settings:
    return Settings()
