from datetime import datetime

from pydantic import BaseModel

from app.models.enums import AppointmentStatus, VerificationTarget


class AppointmentRecord(BaseModel):
    appointment_id: str
    scheduled_at: datetime
    provider: str | None = None
    location: str | None = None
    status: AppointmentStatus = AppointmentStatus.SCHEDULED
    missed_count: int = 0
    reschedule_count: int = 0
    reschedule_allowed: bool = False
    attended_at: datetime | None = None
    last_missed_at: datetime | None = None
    attendance_source: str | None = None
    updated_at: datetime

    @property
    def attendance_target(self) -> VerificationTarget:
        if self.reschedule_count > 0:
            return VerificationTarget.RESCHEDULED_APPOINTMENT_ATTENDANCE
        return VerificationTarget.APPOINTMENT_ATTENDANCE
