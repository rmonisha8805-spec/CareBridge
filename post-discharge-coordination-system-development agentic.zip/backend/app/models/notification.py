from datetime import datetime

from pydantic import BaseModel

from app.models.enums import NotificationChannel, NotificationStatus, RecipientType, StaffRole


class NotificationRecord(BaseModel):
    """A dispatched message. Dispatch is an action, never evidence that care happened."""

    notification_id: str
    task_id: str
    patient_id: str
    recipient_type: RecipientType
    recipient_role: StaffRole | None = None
    channel: NotificationChannel | None
    message_type: str
    message: str
    status: NotificationStatus
    error: str | None = None
    created_at: datetime
