from datetime import datetime
from typing import Any, Literal

from pydantic import AwareDatetime, BaseModel, Field

from app.models.enums import AppointmentStatus, EventType


class WorkflowEvent(BaseModel):
    """An external fact or request that triggers one pass through the care graph."""

    type: EventType
    payload: dict[str, Any] = Field(default_factory=dict)
    occurred_at: datetime
    actor: str | None = None


class AppointmentStatusPayload(BaseModel):
    status: Literal[AppointmentStatus.COMPLETED, AppointmentStatus.MISSED]
    occurred_at: AwareDatetime | None = None
    source: str


class ReschedulePayload(BaseModel):
    new_scheduled_at: AwareDatetime
    reason: str | None = None


class AvailabilityPayload(BaseModel):
    available: bool
    source: str


class CollectionPayload(BaseModel):
    collected: bool
    collected_at: AwareDatetime | None = None
    source: str


class EscalationRequestPayload(BaseModel):
    reason: str


class EscalationAcknowledgePayload(BaseModel):
    escalation_id: str
    staff_id: str


class EscalationResolutionPayload(BaseModel):
    escalation_id: str
    resolved_by: str
    note: str | None = None
