from datetime import datetime

from pydantic import BaseModel

from app.models.enums import CollectionStatus, MedicationStatus

AVAILABLE_STATUSES = frozenset({MedicationStatus.IN_STOCK, MedicationStatus.RESTOCKED})


class MedicationRecord(BaseModel):
    medication_id: str
    name: str
    dosage: str | None = None
    pharmacy: str | None = None
    availability: MedicationStatus = MedicationStatus.UNKNOWN
    collection_status: CollectionStatus = CollectionStatus.NOT_COLLECTED
    out_of_stock_since: datetime | None = None
    available_since: datetime | None = None
    restocked_at: datetime | None = None
    patient_notified_at: datetime | None = None
    collection_deadline: datetime | None = None
    collected_at: datetime | None = None
    collection_source: str | None = None
    updated_at: datetime

    @property
    def is_available(self) -> bool:
        return self.availability in AVAILABLE_STATUSES

    @property
    def is_collected(self) -> bool:
        return self.collection_status == CollectionStatus.COLLECTED and self.collected_at is not None

    def follow_up_expired(self, now: datetime) -> bool:
        return (
            self.is_available
            and not self.is_collected
            and self.collection_deadline is not None
            and now >= self.collection_deadline
        )
