from datetime import datetime

from pydantic import BaseModel, Field

from app.models.enums import EvidenceOutcome, VerificationStatus, VerificationTarget


class VerificationEvidence(BaseModel):
    """Independent confirmation or refutation of a care action (e.g. pharmacy dispense log)."""

    target: VerificationTarget
    outcome: EvidenceOutcome
    source: str
    notes: str | None = None
    observed_at: datetime


class VerificationRecord(BaseModel):
    target: VerificationTarget
    status: VerificationStatus
    reason: str
    checked_at: datetime
    evidence_source: str | None = None


class VerificationState(BaseModel):
    status: VerificationStatus = VerificationStatus.PENDING
    target: VerificationTarget | None = None
    records: dict[VerificationTarget, VerificationRecord] = Field(default_factory=dict)
    last_checked_at: datetime | None = None
