from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field

from app.models.enums import EscalationStatus, StaffRole, TaskType

ESCALATION_TARGETS: dict[TaskType, StaffRole] = {
    TaskType.APPOINTMENT: StaffRole.CARE_COORDINATOR,
    TaskType.MEDICATION: StaffRole.NURSE,
}


class EscalationRecord(BaseModel):
    escalation_id: str
    patient_id: str
    task_id: str
    task_type: TaskType
    reason: str
    target_role: StaffRole
    status: EscalationStatus = EscalationStatus.OPEN
    context: dict[str, Any] = Field(default_factory=dict)
    acknowledged_by: str | None = None
    resolved_at: datetime | None = None
    resolution_note: str | None = None
    created_at: datetime
    updated_at: datetime

    @property
    def is_active(self) -> bool:
        return self.status != EscalationStatus.RESOLVED
