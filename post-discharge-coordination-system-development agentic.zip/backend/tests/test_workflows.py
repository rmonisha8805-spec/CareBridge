import httpx
import pytest

pytestmark = pytest.mark.asyncio


async def create_appointment(client: httpx.AsyncClient, channel: str | None = "SMS") -> dict:
    response = await client.post(
        "/tasks/appointments",
        json={
            "patient_id": "patient-1",
            "patient_channel": channel,
            "appointment": {"scheduled_at": "2026-01-12T10:00:00Z", "provider": "Dr. Lee"},
        },
    )
    assert response.status_code == 201, response.text
    return response.json()


async def create_medication(client: httpx.AsyncClient, availability: str = "IN_STOCK") -> dict:
    response = await client.post(
        "/tasks/medications",
        json={
            "patient_id": "patient-2",
            "patient_channel": "SMS",
            "medication": {"name": "Metoprolol", "availability": availability},
        },
    )
    assert response.status_code == 201, response.text
    return response.json()


async def test_missed_notification_does_not_complete_appointment(client: httpx.AsyncClient) -> None:
    task = await create_appointment(client)
    assert task["task_status"] == "AWAITING_EVENT"

    missed = await client.post(
        f"/tasks/{task['task_id']}/appointment/status", json={"status": "MISSED", "source": "ehr"}
    )
    body = missed.json()
    assert body["notifications"][-1]["status"] == "SENT"
    assert body["appointment"]["reschedule_allowed"] is True
    assert body["task_status"] != "COMPLETED"
    assert body["completed_at"] is None


async def test_appointment_completes_on_sourced_attendance(client: httpx.AsyncClient) -> None:
    task = await create_appointment(client)
    status = await client.post(
        f"/tasks/{task['task_id']}/appointment/status", json={"status": "COMPLETED", "source": "ehr"}
    )
    assert status.status_code == 200, status.text
    body = status.json()
    assert body["task_status"] == "COMPLETED"
    assert body["completed_at"] is not None

    records = await client.get(f"/tasks/{task['task_id']}/verifications")
    assert any(r["status"] == "VERIFIED" and r["evidence_source"] == "ehr" for r in records.json())

    rejected = await client.post(f"/tasks/{task['task_id']}/monitor")
    assert rejected.status_code == 422


async def test_not_confirmed_evidence_blocks_completion(client: httpx.AsyncClient) -> None:
    task = await create_appointment(client)
    task_id = task["task_id"]
    disputed = await client.post(
        f"/tasks/{task_id}/verification/evidence",
        json={"target": "APPOINTMENT_ATTENDANCE", "outcome": "NOT_CONFIRMED", "source": "clinic-checkin"},
    )
    assert disputed.status_code == 200, disputed.text
    assert disputed.json()["task_status"] != "COMPLETED"

    confirmed = await client.post(
        f"/tasks/{task_id}/verification/evidence",
        json={"target": "APPOINTMENT_ATTENDANCE", "outcome": "CONFIRMED", "source": "clinic-checkin"},
    )
    assert confirmed.json()["task_status"] == "COMPLETED"


async def test_repeated_missed_appointments_escalate_to_coordinator(client: httpx.AsyncClient) -> None:
    task = await create_appointment(client)
    task_id = task["task_id"]

    first = await client.post(f"/tasks/{task_id}/appointment/status", json={"status": "MISSED", "source": "ehr"})
    assert first.json()["task_status"] != "ESCALATED"

    rescheduled = await client.post(
        f"/tasks/{task_id}/appointment/reschedule", json={"new_scheduled_at": "2026-01-15T10:00:00Z"}
    )
    assert rescheduled.status_code == 200, rescheduled.text

    response = await client.post(f"/tasks/{task_id}/appointment/status", json={"status": "MISSED", "source": "ehr"})
    assert response.status_code == 200, response.text

    body = response.json()
    assert body["task_status"] == "ESCALATED"
    assert body["escalation"]["target_role"] == "CARE_COORDINATOR"
    assert body["escalation"]["status"] == "OPEN"

    open_escalations = await client.get("/escalations", params={"status": "OPEN"})
    assert [e["task_id"] for e in open_escalations.json()] == [task_id]


async def test_escalation_cannot_resolve_without_verified_outcome(client: httpx.AsyncClient) -> None:
    task = await create_appointment(client)
    task_id = task["task_id"]
    requested = await client.post(
        f"/tasks/{task_id}/escalations", json={"reason": "Patient unreachable", "requested_by": "nurse-7"}
    )
    assert requested.status_code == 200, requested.text
    escalation_id = requested.json()["escalation"]["escalation_id"]

    ack = await client.post(f"/escalations/{escalation_id}/acknowledge", json={"staff_id": "cc-1"})
    assert ack.status_code == 200, ack.text
    assert ack.json()["escalation"]["status"] == "IN_PROGRESS"

    premature = await client.post(f"/escalations/{escalation_id}/resolve", json={"resolved_by": "cc-1"})
    assert premature.status_code == 409
    assert premature.json()["task"]["escalation"]["status"] != "RESOLVED"

    attended = await client.post(
        f"/tasks/{task_id}/appointment/status", json={"status": "COMPLETED", "source": "ehr"}
    )
    assert attended.status_code == 200, attended.text
    body = attended.json()
    assert body["escalation"]["status"] == "RESOLVED"
    assert body["task_status"] == "COMPLETED"


async def test_out_of_stock_medication_waits_for_restock_then_collection(client: httpx.AsyncClient) -> None:
    task = await create_medication(client, availability="OUT_OF_STOCK")
    task_id = task["task_id"]
    assert task["task_status"] == "AWAITING_EVENT"

    restocked = await client.post(
        f"/tasks/{task_id}/medication/availability", json={"available": True, "source": "pharmacy"}
    )
    assert restocked.status_code == 200, restocked.text
    body = restocked.json()
    assert body["medication"]["availability"] == "RESTOCKED"
    assert body["task_status"] != "COMPLETED"
    assert any(n["recipient_type"] == "PATIENT" for n in body["notifications"])

    collected = await client.post(
        f"/tasks/{task_id}/medication/collection", json={"collected": True, "source": "pharmacy-pos"}
    )
    assert collected.status_code == 200, collected.text
    assert collected.json()["task_status"] == "COMPLETED"


async def test_uncollected_medication_escalates_to_nurse_after_follow_up_window(
    client: httpx.AsyncClient, clock
) -> None:
    task = await create_medication(client)
    task_id = task["task_id"]

    clock.advance(hours=73)
    response = await client.post(f"/tasks/{task_id}/monitor")
    for _ in range(5):
        if response.json()["task_status"] == "ESCALATED":
            break
        response = await client.post(f"/tasks/{task_id}/monitor")

    body = response.json()
    assert body["task_status"] == "ESCALATED", body["audit_log"]
    assert body["escalation"]["target_role"] == "NURSE"


async def test_event_type_must_match_task_type(client: httpx.AsyncClient) -> None:
    task = await create_medication(client)
    response = await client.post(
        f"/tasks/{task['task_id']}/appointment/status", json={"status": "MISSED", "source": "ehr"}
    )
    assert response.status_code == 422


async def test_unknown_task_returns_404(client: httpx.AsyncClient) -> None:
    response = await client.get("/tasks/does-not-exist")
    assert response.status_code == 404
