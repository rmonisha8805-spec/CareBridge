from collections.abc import AsyncIterator
from datetime import UTC, datetime, timedelta
from pathlib import Path

import httpx
import pytest
import pytest_asyncio

from app.config import Settings
from app.main import create_app


class FakeClock:
    def __init__(self) -> None:
        self.now = datetime(2026, 1, 10, 9, 0, tzinfo=UTC)

    def __call__(self) -> datetime:
        return self.now

    def advance(self, **kwargs: float) -> None:
        self.now += timedelta(**kwargs)


@pytest.fixture
def clock() -> FakeClock:
    return FakeClock()


@pytest_asyncio.fixture
async def client(tmp_path: Path, clock: FakeClock) -> AsyncIterator[httpx.AsyncClient]:
    settings = Settings(database_url=f"sqlite:///{tmp_path / 'test.db'}", _env_file=None)
    app = create_app(settings=settings, clock=clock)
    async with app.router.lifespan_context(app):
        transport = httpx.ASGITransport(app=app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as http:
            yield http
